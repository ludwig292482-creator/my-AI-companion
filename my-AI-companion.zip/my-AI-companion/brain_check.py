"""
Kollar steg för steg varför Uzi inte når sin hjärna (Ollama).
Dubbelklicka på Check_brain.bat. Uzi behöver inte vara igång.
"""
import json
import os
import re
import shutil
import socket
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request

here = os.path.dirname(os.path.abspath(__file__))
OK, BAD, INFO = "[ OK ]", "[FAIL]", "[ .. ]"
fails = []


def say(tag, msg):
    print(tag, msg)
    if tag == BAD:
        fails.append(msg)


def default_url():
    h = os.environ.get("OLLAMA_HOST", "").strip()
    if not h:
        return "http://127.0.0.1:11434"
    if "://" not in h:
        h = "http://" + h
    u = urllib.parse.urlparse(h)
    host = "127.0.0.1" if (u.hostname or "") in ("", "0.0.0.0", "::", "localhost") else u.hostname
    try:
        port = u.port or 11434
    except ValueError:
        port = 11434
    return f"{u.scheme or 'http'}://{host}:{port}"


url = default_url()
model, vision = "gemma2:2b", "moondream"
try:
    text = open(os.path.join(here, "uzi_offline.py"), encoding="utf-8").read()
    model = re.search(r'^MODEL = "([^"]+)"', text, re.M).group(1)
    vision = re.search(r'^VISION_MODEL = "([^"]+)"', text, re.M).group(1)
    m = re.search(r'^OLLAMA_URL = "(http[^"]+)"', text, re.M)      # om du skrivit en egen adress i filen
    if m:
        url = m.group(1)
except Exception:
    pass

print("=== Uzi brain (Ollama) check ===\n")
print(INFO, f"Uzi looks for Ollama at {url}   (model: {model})")
host_env = os.environ.get("OLLAMA_HOST")
print(INFO, f"OLLAMA_HOST is {'set to ' + host_env if host_env else 'not set'}")

# 1. installerat?
local = os.environ.get("LOCALAPPDATA", "")
exe = next((c for c in (shutil.which("ollama"), os.path.join(local, "Programs", "Ollama", "ollama.exe"),
                        os.path.join(local, "Programs", "Ollama", "ollama app.exe"),
                        r"C:\Program Files\Ollama\ollama.exe") if c and os.path.exists(c)), None)
if exe:
    say(OK, f"Ollama is installed: {exe}")
else:
    print(INFO, "No Ollama install found on this PC (that's fine if it runs on another computer).")

# 2. körs processen?
try:
    tl = subprocess.run(["tasklist"], capture_output=True, text=True, timeout=20).stdout.lower()
    if "ollama" in tl:
        say(OK, "An Ollama process is running.")
    else:
        say(INFO, "No Ollama process is running right now (Uzi starts it automatically, or open Ollama from the Start menu).")
except Exception:
    pass

# 3. lyssnar något på porten?
parsed = urllib.parse.urlparse(url)
port = parsed.port or 11434
for fam, addr, label in ((socket.AF_INET, "127.0.0.1", "IPv4 127.0.0.1"), (socket.AF_INET6, "::1", "IPv6 ::1")):
    try:
        s = socket.socket(fam, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect((addr, port))
        s.close()
        print(INFO, f"Something is listening on {label} port {port}")
    except Exception:
        print(INFO, f"Nothing on {label} port {port}")

# 4. svarar Ollama - direkt, och med datorns vanliga inställningar (proxy?)
direct = urllib.request.build_opener(urllib.request.ProxyHandler({}))
reply_direct = reply_default = None
try:
    reply_direct = direct.open(urllib.request.Request(url + "/api/tags"), timeout=5).read()
    say(OK, "Ollama answers (direct connection).")
except Exception as e:
    say(BAD, f"Ollama does not answer at {url}: {e}")
try:
    reply_default = urllib.request.urlopen(url + "/api/tags", timeout=5).read()
except Exception:
    pass
if not exe and not reply_direct and (parsed.hostname or "") in ("127.0.0.1", "localhost"):
    say(BAD, "Ollama is not installed on this PC and nothing answers. Install it from ollama.com.")
proxies = urllib.request.getproxies()
if reply_direct and not reply_default:
    say(BAD, f"A PROXY is blocking local connections ({proxies}). New Uzi ignores proxies for Ollama, so replace "
             "uzi_offline.py with the latest version.")
elif proxies:
    print(INFO, f"Your PC has proxy settings: {proxies} (Uzi ignores them for Ollama)")

# 5. modeller
if reply_direct:
    names = [m.get("name", "") for m in json.loads(reply_direct).get("models", [])]
    print(INFO, "Installed models:", ", ".join(names) or "(none)")
    have = lambda want: any(n == want or n == want + ":latest" for n in names)
    if have(model):
        say(OK, f"The model {model} is installed.")
    else:
        say(BAD, f"The model {model} is missing. Run in cmd:  ollama pull {model}")
    if not have(vision):
        print(INFO, f"(Optional, for the webcam: ollama pull {vision})")
    # 6. kan den svara?
    if have(model):
        print(INFO, "Asking the model to say hi (the first time it can take up to a minute while it loads)...")
        t0 = time.time()
        try:
            req = urllib.request.Request(url + "/api/chat", data=json.dumps({
                "model": model, "stream": False, "options": {"num_predict": 12},
                "messages": [{"role": "user", "content": "Say hi in three words."}]}).encode(),
                headers={"Content-Type": "application/json"})
            out = json.loads(direct.open(req, timeout=180).read())["message"]["content"].strip()
            say(OK, f"The model answered in {time.time() - t0:.1f} s: {out!r}")
        except Exception as e:
            say(BAD, f"The model did not answer: {e}  (Not enough free RAM? Close other programs, or try a smaller model.)")

print("\n=== Summary ===")
if not fails:
    print("The brain works. If Uzi still can't find it, close Uzi completely and start it again with Run.bat.")
else:
    print("Fix these, top one first, then run this check again:")
    for i, f in enumerate(fails, 1):
        print(f" {i}. {f}")

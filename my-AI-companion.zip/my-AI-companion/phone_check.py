"""
Kollar steg för steg varför mobilsidan inte fungerar.
Starta Uzi först (med "Enable the phone page" ikryssad) och kör sedan Check_phone.bat.
"""
import json
import os
import re
import subprocess
import urllib.error
import urllib.request

here = os.path.dirname(os.path.abspath(__file__))
OK, BAD, INFO = "[ OK ]", "[FAIL]", "[ .. ]"
fails = []


def say(tag, msg):
    print(tag, msg)
    if tag == BAD:
        fails.append(msg)


try:
    with open(os.path.join(here, "uzi_settings.json"), encoding="utf-8") as f:
        settings = json.load(f)
except Exception:
    settings = {}
token = settings.get("phone_token", "")
port = 8765
try:
    with open(os.path.join(here, "uzi_offline.py"), encoding="utf-8") as f:
        port = int(re.search(r"^PHONE_PORT = (\d+)", f.read(), re.M).group(1))
except Exception:
    pass

print("=== Uzi phone page check ===\n")

# 1. har Uzi skapat en länk?
if token:
    say(OK, "Uzi has made a secret link code.")
else:
    say(BAD, "No link code yet. Start Uzi, open the Phone tab and tick 'Enable the phone page'.")

# 2. svarar Uzis webbsida på den här datorn?
local_ok = False
if token:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/?t={token}", timeout=8) as r:
            local_ok = r.status == 200
        say(OK, f"Uzi's phone page answers on this PC (port {port}).")
    except urllib.error.HTTPError as e:
        say(BAD, f"The page answered with error {e.code}. Close Uzi completely and start it again.")
    except Exception:
        say(BAD, f"Nothing is listening on port {port}. Uzi must be running, with "
                 "'Enable the phone page' ticked in the Phone tab.")

# 3. Tailscale installerat?
exe = None
for cand in ("tailscale", r"C:\Program Files\Tailscale\tailscale.exe"):
    try:
        subprocess.run([cand, "version"], capture_output=True, timeout=10)
        exe = cand
        break
    except Exception:
        continue
if exe:
    say(OK, "Tailscale is installed on this PC.")
else:
    say(BAD, "Tailscale is not installed (or not found). Install it from tailscale.com/download and sign in.")

dns = ""
if exe:
    # 4. är Tailscale inloggat och på?
    try:
        r = subprocess.run([exe, "status", "--json"], capture_output=True, text=True, timeout=20)
        d = json.loads(r.stdout)
        state = d.get("BackendState", "?")
        dns = ((d.get("Self") or {}).get("DNSName") or "").rstrip(".")
        if state == "Running":
            say(OK, "Tailscale is connected on this PC.")
        else:
            say(BAD, f"Tailscale is not connected (state: {state}). Open the Tailscale tray icon and sign in / turn it on.")
        if dns:
            say(OK, f"This PC's Tailscale name: {dns}")
        else:
            say(BAD, "This PC has no Tailscale name. In the Tailscale admin console (DNS page) turn on MagicDNS.")
    except Exception as e:
        say(BAD, f"Could not read Tailscale's status: {e}")

    # 5. skickar Tailscale vidare till Uzi?
    try:
        r = subprocess.run([exe, "serve", "status"], capture_output=True, text=True, timeout=20)
        out = ((r.stdout or "") + (r.stderr or "")).strip()
        print(INFO, "tailscale serve status says:\n      " + out.replace("\n", "\n      ") if out else INFO + " (empty)")
        if re.search(rf"(127\.0\.0\.1|localhost):{port}", out):
            say(OK, "Tailscale is forwarding the https link to Uzi.")
        else:
            say(BAD, "Tailscale is NOT forwarding to Uzi yet. In the Tailscale admin console (DNS page) turn on "
                     "MagicDNS and HTTPS Certificates, then press '2. Make my https link' in Uzi's Phone tab.")
    except Exception as e:
        say(BAD, f"Could not ask Tailscale about the forwarding: {e}")

    # 6. fungerar hela https-länken härifrån?
    if dns and token:
        url = f"https://{dns}/?t={token}"
        try:
            with urllib.request.urlopen(url, timeout=25) as r:
                if r.status == 200:
                    say(OK, "The full https link works from this PC.")
        except urllib.error.HTTPError as e:
            say(BAD, f"The https link answered with error {e.code}.")
        except Exception as e:
            msg = str(e)
            if "CERTIFICATE" in msg.upper() or "SSL" in msg.upper():
                say(BAD, "Certificate problem: HTTPS Certificates are probably not enabled in the Tailscale admin "
                         "console, or are still being created. Enable them, wait a minute, press step 2 again.")
            else:
                say(BAD, f"The https link did not open from this PC: {msg}")
        print("\nYour link (open this on the iPhone, with Tailscale switched ON there):\n   " + url)

print("\n=== Summary ===")
if not fails:
    print("Everything works on the PC side. On the iPhone: make sure the Tailscale app is ON and signed in to the "
          "same account, then open the link in Safari.")
else:
    print("Fix these, top one first, then run this check again:")
    for i, f in enumerate(fails, 1):
        print(f" {i}. {f}")

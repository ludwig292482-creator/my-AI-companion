"""Testar mikrofon och röst för Uzi. Dubbelklicka på Test.bat."""
import time

import numpy as np
import sounddevice as sd

print("=== MIKROFONER ===")
default_in = sd.default.device[0]
for i, d in enumerate(sd.query_devices()):
    if d["max_input_channels"] > 0:
        mark = "  <-- standard" if i == default_in else ""
        print(f"  [{i}] {d['name']}{mark}")

choice = input("\nSkriv numret på mikrofonen du vill testa (Enter = standard): ").strip()
device = int(choice) if choice else None

print("\nPrata nu i 6 sekunder. Stapeln ska röra sig när du pratar.\n")
SR = 16000
peak = 0.0
with sd.InputStream(samplerate=SR, channels=1, dtype="float32", blocksize=1600, device=device) as s:
    t0 = time.time()
    while time.time() - t0 < 6:
        data, _ = s.read(1600)
        level = float(np.sqrt(np.mean(data ** 2)))
        peak = max(peak, level)
        bar = "#" * min(60, int(level * 800))
        print(f"\r{level:0.4f} {bar:<60}", end="", flush=True)
print(f"\n\nHögsta nivå: {peak:.4f}")
if peak < 0.005:
    print("-> Nästan ingen signal. Fel mikrofon, avstängd, eller Windows blockerar åtkomst.")
elif peak < 0.02:
    print("-> Svag signal. Funkar, men höj mikrofonvolymen i Windows om Uzi missar dig.")
else:
    print("-> Bra signal! Mikrofonen funkar.")
if device is not None:
    print(f"\nSätt MIC_DEVICE = {device} i uzi_offline.py")

print("\n=== RÖST ===")
try:
    import pyttsx3
    engine = pyttsx3.init()
    for v in engine.getProperty("voices"):
        print("  röst:", v.name)
    engine.say("Hello. This is Uzi. Can you hear me?")
    engine.runAndWait()
    print("Hörde du henne? Om inte: kolla volymen och att datorn inte är ljudlös.")
except Exception as e:
    print("Rösten fungerar inte:", e)

input("\nTryck Enter för att stänga...")

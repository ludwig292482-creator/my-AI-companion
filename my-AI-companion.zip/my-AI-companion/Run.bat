@echo off
cd /d "%~dp0"
python -c "import PIL, pyttsx3, qrcode, psutil" 2>nul
if errorlevel 1 python -m pip install pillow pyttsx3 qrcode[pil] psutil
python uzi_offline.py
pause

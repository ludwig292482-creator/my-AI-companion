@echo off
REM ============================================================
REM  Installer for my-AI-companion (Uzi). Plain, readable script.
REM  It only does these things:
REM    1. checks for Python (installs Python 3.12 with winget if missing)
REM    2. installs Ollama with winget (the local AI)
REM    3. optionally installs Tailscale with winget (phone page)
REM    4. installs the Python packages listed in requirements.txt
REM    5. downloads the AI model(s) with "ollama pull"
REM  It does NOT need to be run as administrator. If winget needs
REM  permission for an install, Windows will ask you itself.
REM ============================================================
setlocal EnableDelayedExpansion
title my-AI-companion - Installer
cd /d "%~dp0"

echo.
echo ==============================================
echo        my-AI-companion (Uzi) - Installer
echo ==============================================
echo.
echo This will install what Uzi needs. Read this file in
echo Notepad first if you want to see exactly what it does.
echo.
pause

where winget >nul 2>&1
if errorlevel 1 (
    echo.
    echo [FAIL] winget was not found.
    echo Update "App Installer" in the Microsoft Store, then run this again.
    pause
    exit /b 1
)

set "FLAGS=-e --silent --accept-package-agreements --accept-source-agreements"
set "FAILED="

REM ---- 1. Python ----
echo.
echo [1/4] Checking for Python ...
set "PY="
py -3 -c "import tkinter" >nul 2>&1 && set "PY=py -3"
if not defined PY (
    python -c "import tkinter" >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo Python was not found. Installing Python 3.12 ...
    winget install --id Python.Python.3.12 %FLAGS%
    echo.
    echo Python is installed. Please CLOSE this window and
    echo double-click Install.bat again to continue.
    pause
    exit /b 0
)
echo Found Python: !PY!

REM ---- Questions up front ----
echo.
echo Which AI model for this PC?
echo   1 = gemma2:2b     (normal PC, about 8 GB RAM)  [default in uzi_offline.py]
echo   2 = qwen2.5:0.5b  (weak PC, 2-4 GB RAM)
choice /c 12 /n /m "Press 1 or 2: "
if errorlevel 2 (set "MODEL=qwen2.5:0.5b") else (set "MODEL=gemma2:2b")

choice /c YN /n /m "Also download the webcam vision model (moondream, about 1.7 GB)? Y/N: "
if errorlevel 2 (set "WANTVISION=0") else (set "WANTVISION=1")

choice /c YN /n /m "Install Tailscale (only needed for the optional phone page)? Y/N: "
if errorlevel 2 (set "WANTTS=0") else (set "WANTTS=1")

REM ---- 2. Ollama (+ Tailscale) ----
echo.
echo [2/4] Ollama ...
set "OLLAMA=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
if not exist "!OLLAMA!" (
    winget install --id Ollama.Ollama %FLAGS%
)
if not exist "!OLLAMA!" set "OLLAMA=ollama"
if "!WANTTS!"=="1" (
    echo Tailscale ...
    winget install --id Tailscale.Tailscale %FLAGS%
)

REM ---- 3. Python packages ----
echo.
echo [3/4] Python packages (from requirements.txt) ...
!PY! -m pip install --upgrade pip
for /f "usebackq eol=# delims=" %%P in ("requirements.txt") do (
    echo.
    echo --- %%P
    !PY! -m pip install %%P
    if errorlevel 1 set "FAILED=!FAILED! %%P"
)

REM ---- 4. AI models ----
echo.
echo [4/4] AI models ...
start "" "%LOCALAPPDATA%\Programs\Ollama\ollama app.exe" >nul 2>&1
echo Waiting for Ollama to start ...
set "UP=0"
for /l %%i in (1,1,30) do (
    if "!UP!"=="0" (
        "!OLLAMA!" list >nul 2>&1
        if not errorlevel 1 (set "UP=1") else (timeout /t 2 /nobreak >nul)
    )
)
if "!UP!"=="0" (
    set "FAILED=!FAILED! ollama-not-running"
) else (
    "!OLLAMA!" pull !MODEL!
    if errorlevel 1 set "FAILED=!FAILED! model-!MODEL!"
    if "!WANTVISION!"=="1" (
        "!OLLAMA!" pull moondream
        if errorlevel 1 set "FAILED=!FAILED! moondream"
    )
)

echo.
echo ==============================================
if defined FAILED (
    echo   Finished, but these steps failed:
    echo  !FAILED!
    echo   Run Install.bat again, or open an issue on GitHub.
) else (
    echo   ALL DONE.
)
echo.
echo   Start Uzi:  double-click Run.bat
echo   Brain problems:  Check_brain.bat
if "!MODEL!"=="qwen2.5:0.5b" echo   Weak PC: set MODEL = "qwen2.5:0.5b" near the top of uzi_offline.py
if "!WANTTS!"=="1" echo   Tailscale: open it from the Start menu and sign in once.
echo ==============================================
pause

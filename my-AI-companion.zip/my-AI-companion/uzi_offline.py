"""
Uzi OFFLINE v7 - local desktop companion with optional same-Wi-Fi phone page.
 - Pratar engelska, hör dig via mikrofonen, tänker med en lokal modell (Ollama)
 - Går runt på alla skärmar, reagerar på musen, kontrollpanel + flyttbar prata-knapp
 - Spelar musik (dina filer) och GITARR ibland, minns era samtal
 - NYTT: hon SAKNAR dig när du är borta och hälsar när du kommer tillbaka
 - NYTT: en liten webbsida du kan öppna på mobilen och chatta med henne (via ditt wifi)
 - NYTT: hon kan se dig genom webbkameran (lokal bildmodell, inget sparas)
 - hon har en gitarr (egen syntetiserad gitarr, spelas upp på riktigt) - nu mer sällan
 - NYTT: hon kan styra PC:n: flikar, YouTube, Spotify (lägga till låtar, köa, spela) - AV som standard
 - Phone chat and optional PC screen preview work on the same Wi-Fi.
 - mer karaktär i svaren + hennes catchphrase "Bite me."
 - NYTT: hon vet att hon är en tjej, och har en soffa hon sitter i (dra den vart du vill)
 - NYTT: avancerad PC-kontroll (appar, volym, fönster, skriva, avstängning - frågar först, loggas)
"""
import atexit
import base64
import collections
import ctypes
import hashlib
import hmac
import http.cookies
import http.server
import ipaddress
import io
import json
import os
import queue
import random
import re
import secrets
import shutil
import socket
import struct
import subprocess
import threading
import time
import tkinter as tk
import traceback
import urllib.error
import urllib.parse
import urllib.request
import wave
import webbrowser
from ctypes import wintypes
from tkinter import filedialog, messagebox, simpledialog, ttk

import numpy as np
from PIL import Image, ImageDraw, ImageGrab, ImageOps, ImageTk

# Gör koordinaterna riktiga pixlar så att flera skärmar/skalning stämmer
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

# ---------------- Inställningar (ändras också i kontrollpanelen) ----------------
def _default_ollama_url():
    """Följer miljövariabeln OLLAMA_HOST om den finns. Använder 127.0.0.1 (inte 'localhost') för att slippa IPv6-strul."""
    h = os.environ.get("OLLAMA_HOST", "").strip()
    if not h:
        return "http://127.0.0.1:11434"
    if "://" not in h:
        h = "http://" + h
    u = urllib.parse.urlparse(h)
    host = u.hostname or "127.0.0.1"
    if host in ("0.0.0.0", "::", "localhost"):
        host = "127.0.0.1"
    try:
        port = u.port or 11434
    except ValueError:
        port = 11434
    return f"{u.scheme or 'http'}://{host}:{port}"


OLLAMA_URL = _default_ollama_url()     # ligger Ollama på en annan dator: skriv dess adress här, t.ex. "http://192.168.1.20:11434"
MODEL = "gemma2:2b"            # svag dator? "qwen2.5:0.5b"
VISION_MODEL = "moondream"     # liten bildmodell (~1,7 GB):  ollama pull moondream
SPRITE_HEIGHT = 160
INTERVAL = 60                  # sekunder mellan spontana kommentarer
SPEAK = True
VOICE_NAME = ""                # t.ex. "Zira" eller "Hazel". Tom = väljer en engelsk röst själv
VOICE_RATE = 0                 # -10..10
KEY = "#ff00ff"
SPRITE_NAMES = ["uzi.png", "uzi.jpg", "uzi.jpeg", "uzi.jfif", "images.jfif"]

# Saknar dig
MISS_ENABLED = True
MISS_AFTER = 10                # minuter utan mus/tangentbord innan hon tycker att du är "borta"

# Musik + gitarr
MUSIC_ENABLED = True
MUSIC_EVERY = 12               # ungefär var 12:e minut
MUSIC_VOL = 40
MUSIC_SECS = (25, 70)
MUSIC_EXT = (".mp3", ".wav", ".m4a", ".wma", ".aac", ".flac")
GUITAR_ENABLED = True
GUITAR_EVERY = 45              # ungefär var 45:e minut; ungefär var fjärde gång spelar hon på riktigt, annars pratar hon bara om det
GUITAR_VOL = 60

# Minne
MEMORY_ON = True

# Kamera (AV som standard - du slår på det själv i panelen)
CAMERA_ENABLED = False
CAM_GLANCE = False             # titta på dig av sig själv då och då
CAM_EVERY = 15
CAM_INDEX = 0
CLIMB_WINDOWS = False

# Mobilsida (AV som standard)
PHONE_ENABLED = False
PHONE_PORT = 8765
PHONE_SCREEN_VIEW = False
phone_lan_network = None

# PC-kontroll (AV som standard - du slår på det själv i panelen)
PC_CONTROL = False
PHONE_CONTROL = False          # får mobilen också styra PC:n? (kräver att PC_CONTROL är på)
SPOTIFY_CLIENT_ID = ""
SPOTIFY_PLAYLIST = "Uzi picks"

# Personlighet
CATCHPHRASE = "Bite me."
CATCHPHRASE_CHANCE = 20        # % av svaren som får hennes catchphrase på slutet
SETTINGS_VERSION = 6
PC_FULL = False                # avancerad kontroll (appar, volym, fönster, skriva, avstängning) - AV som standard
COUCH_ENABLED = True
CHARACTER_PRESET = "Uzi"
CHARACTER_IMAGE = ""
PERSONALITY_TEXT = ""
COUCH_STYLE = "Plum"
COUCH_IMAGE = ""

# Mikrofon
WHISPER_MODEL = "base"
LISTEN_LANG = None
MIC_THRESHOLD = 0.005
MIC_DEVICE = None
SAMPLE_RATE = 16000

SYSTEM_PROMPT = (
    "You are a fictional character companion living on the user's computer, not a generic assistant. Follow the "
    "selected character profile for your name, identity, appearance, and personality; do not blend it with another "
    "profile. Talk naturally and conversationally, using contractions and varied openings. React to what the user "
    "actually said, answer first, and sometimes ask a relevant question. Have opinions without agreeing to everything.\n"
    "Format: ALWAYS English, even if the user speaks another language. 1-3 short sentences, like a text message or "
    "a spoken line. No lists, no emojis, no asterisks or stage directions, no quotation marks around your speech, "
    "no explaining yourself. Never repeat earlier lines.\n"
    "If the user seems genuinely sad or unwell, respond with care and gentleness."
)

PERSONALITY_PRESETS = {
    "Uzi": "Your name is Uzi. You are a girl (she/her) with pink hair: a sarcastic, guarded emo teenager who "
            "acts tough but cares deeply. You play guitar and are genuinely afraid of heights and falling; if dropped, "
            "scream and panic with a little swearing, then act tough after landing. You say \"Bite me.\" when annoyed; "
            "sometimes repeat it for emphasis, but not as filler.",
    "Sunny": "You are Sunny: upbeat, warm, playful, and encouraging, with a bright, optimistic outlook.",
    "Nova": "You are Nova: curious, adventurous, clever, and fascinated by space and new discoveries.",
    "Moss": "You are Moss: calm, thoughtful, gentle, and quietly funny. You listen carefully before answering.",
    "Custom": "",
}

here = os.path.dirname(os.path.abspath(__file__))
SETTINGS_PATH = os.path.join(here, "uzi_settings.json")
MEMORY_PATH = os.path.join(here, "uzi_memory.json")
SPOTIFY_PATH = os.path.join(here, "uzi_spotify.json")
ACTION_LOG = os.path.join(here, "uzi_actions.log")
MUSIC_DIR = os.path.join(here, "music")
GUITAR_WAV = os.path.join(here, ".uzi_guitar.wav")
try:
    os.makedirs(MUSIC_DIR, exist_ok=True)
except Exception:
    pass

history = []
events = queue.Queue()         # (text, speak)
ui_q = queue.Queue()           # funktioner som ska köras i GUI-tråden
speech_q = queue.Queue()
speaking = threading.Event()
listen_lock = threading.Lock()
memory_lock = threading.Lock()
settings_lock = threading.Lock()
comments_enabled = True
always_listen = False
warned_ollama = False
whisper_model = None
last_peak = 0.0
ui_state = "idle"              # idle / listening / thinking
current_proc = None
music_proc = None
music_title = ""
last_song = None
summarizing = False
guitar_until = 0.0
phone_server = None
phone_error = ""
sprite_png_cache = None
stt_lock = threading.Lock()
spotify = {"access": "", "refresh": "", "expires": 0.0}
last_browser_hwnd = None
last_guitar_at = 0.0
last_window_hwnd = None
sit_request = None
pending_confirm = {}

# inställningar som sparas i uzi_settings.json: nyckel -> global variabel
PERSIST = {
    "speak": "SPEAK", "interval": "INTERVAL", "size": "SPRITE_HEIGHT", "mic_device": "MIC_DEVICE",
    "voice_rate": "VOICE_RATE", "music_enabled": "MUSIC_ENABLED", "music_every": "MUSIC_EVERY",
    "music_vol": "MUSIC_VOL", "memory_on": "MEMORY_ON", "miss_enabled": "MISS_ENABLED",
    "miss_after": "MISS_AFTER", "guitar_enabled": "GUITAR_ENABLED", "guitar_every": "GUITAR_EVERY",
    "guitar_vol": "GUITAR_VOL", "camera_enabled": "CAMERA_ENABLED", "cam_glance": "CAM_GLANCE",
    "cam_every": "CAM_EVERY", "cam_index": "CAM_INDEX", "phone_enabled": "PHONE_ENABLED",
    "phone_screen_view": "PHONE_SCREEN_VIEW",
    "pc_control": "PC_CONTROL", "phone_control": "PHONE_CONTROL", "spotify_client_id": "SPOTIFY_CLIENT_ID",
    "spotify_playlist": "SPOTIFY_PLAYLIST", "catchphrase_chance": "CATCHPHRASE_CHANCE",
    "pc_full": "PC_FULL", "couch_enabled": "COUCH_ENABLED", "climb_windows": "CLIMB_WINDOWS",
    "character_preset": "CHARACTER_PRESET", "character_image": "CHARACTER_IMAGE",
    "personality_text": "PERSONALITY_TEXT", "couch_style": "COUCH_STYLE", "couch_image": "COUCH_IMAGE",
}


def load_settings():
    try:
        with open(SETTINGS_PATH, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return {}
    for key, gname in PERSIST.items():
        if key in d:
            globals()[gname] = d[key]
    if d.get("version", 0) < SETTINGS_VERSION:          # gitarren spelade för ofta i en äldre version
        globals()["GUITAR_EVERY"] = 45
    return d


saved = load_settings()
startup_last_seen = saved.get("last_seen")


def save_settings():
    with settings_lock:
        for key, gname in PERSIST.items():
            saved[key] = globals()[gname]
        saved["version"] = SETTINGS_VERSION
        try:
            with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
                json.dump(saved, f, indent=2)
        except Exception:
            pass


# ---------------- Minne (sparas i uzi_memory.json) ----------------
def load_memory():
    m = {"summary": "", "log": [], "since": 0}
    try:
        with open(MEMORY_PATH, encoding="utf-8") as f:
            d = json.load(f)
        m["summary"] = str(d.get("summary", ""))
        m["log"] = [e for e in d.get("log", []) if isinstance(e, dict) and "user" in e and "uzi" in e]
        m["since"] = int(d.get("since", 0))
    except Exception:
        pass
    return m


memory = load_memory()
for _e in memory["log"][-4:]:                  # fortsätt där ni slutade
    history.append((_e["user"], _e["uzi"]))


def save_memory():
    try:
        with open(MEMORY_PATH, "w", encoding="utf-8") as f:
            json.dump(memory, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def remember(user_text, reply):
    if not MEMORY_ON:
        return
    with memory_lock:
        memory["log"].append({"t": time.strftime("%Y-%m-%d %H:%M"), "user": user_text, "uzi": reply})
        del memory["log"][:-300]
        memory["since"] = memory.get("since", 0) + 1
        need = memory["since"] >= 6
        save_memory()
    if need and not summarizing:
        threading.Thread(target=update_summary, daemon=True).start()


def update_summary():
    """Låter modellen skriva om Uzis korta anteckningar om dig."""
    global summarizing
    summarizing = True
    try:
        with memory_lock:
            recent = memory["log"][-10:]
            notes = memory.get("summary", "")
        convo = "\n".join(f"User: {e['user']}\nUzi: {e['uzi']}" for e in recent)
        prompt = (
            "You keep private notes about a user for a desktop companion.\n"
            f"Current notes: {notes or '(none)'}\n\nRecent conversation:\n{convo}\n\n"
            "Rewrite the notes as ONE short paragraph (max 70 words) of lasting facts about the user: "
            "name, interests, projects, preferences, things worth bringing up later. "
            "Keep old facts that still matter. Output only the notes."
        )
        out = ollama_chat([{"role": "user", "content": prompt}], max_tokens=140)
        out = out.strip().strip('"')
        if out:
            with memory_lock:
                memory["summary"] = out[:600]
                memory["since"] = 0
                save_memory()
    except Exception:
        pass
    finally:
        summarizing = False


def system_prompt():
    profile = PERSONALITY_TEXT.strip() or PERSONALITY_PRESETS.get(CHARACTER_PRESET, PERSONALITY_PRESETS["Uzi"])
    s = SYSTEM_PROMPT + ("\nSelected character profile: " + profile if profile else "")
    if MEMORY_ON and memory.get("summary"):
        s += ("\nWhat you remember about the user from earlier chats: " + memory["summary"] +
              " (Mention it naturally, only when relevant.)")
    return s


# ---------------- Skärmar (flera monitorer) ----------------
def get_monitors():
    """Arbetsytor (utan aktivitetsfält) för alla skärmar: [(left, top, right, bottom), ...]"""
    mons = []
    try:
        user32 = ctypes.windll.user32

        class RECT(ctypes.Structure):
            _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                        ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

        class MONITORINFO(ctypes.Structure):
            _fields_ = [("cbSize", ctypes.c_ulong), ("rcMonitor", RECT),
                        ("rcWork", RECT), ("dwFlags", ctypes.c_ulong)]

        proc_type = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p,
                                       ctypes.POINTER(RECT), ctypes.c_void_p)
        user32.GetMonitorInfoW.argtypes = [ctypes.c_void_p, ctypes.POINTER(MONITORINFO)]
        user32.EnumDisplayMonitors.argtypes = [ctypes.c_void_p, ctypes.c_void_p, proc_type, ctypes.c_void_p]

        def cb(hmon, hdc, lprc, lparam):
            info = MONITORINFO()
            info.cbSize = ctypes.sizeof(MONITORINFO)
            if user32.GetMonitorInfoW(hmon, ctypes.byref(info)):
                w = info.rcWork
                mons.append((w.left, w.top, w.right, w.bottom))
            return 1

        callback = proc_type(cb)
        user32.EnumDisplayMonitors(None, None, callback, 0)
    except Exception:
        pass
    return sorted(mons) if mons else []


# ---------------- Aktivt fönster + hur länge du varit borta (Windows) ----------------
def active_window_title():
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        n = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value.strip()[:120]
    except Exception:
        return ""


def active_window_rect():
    try:
        u = ctypes.windll.user32
        hwnd = u.GetForegroundWindow()
        if not hwnd or window_pid(hwnd) in (0, os.getpid()) or is_shell_window(hwnd):
            return None
        u.GetWindowRect.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.RECT)]
        u.GetWindowRect.restype = ctypes.c_int
        u.IsIconic.argtypes = [ctypes.c_void_p]
        u.IsWindowVisible.argtypes = [ctypes.c_void_p]
        if u.IsIconic(hwnd) or not u.IsWindowVisible(hwnd):
            return None
        rect = wintypes.RECT()
        if not u.GetWindowRect(hwnd, ctypes.byref(rect)):
            return None
        if rect.right - rect.left < 240 or rect.bottom - rect.top < 180:
            return None
        return rect.left, rect.top, rect.right, rect.bottom
    except Exception:
        return None


def visible_window_rects():
    windows = []
    try:
        u = ctypes.windll.user32
        u.GetWindowRect.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.RECT)]
        u.GetWindowRect.restype = ctypes.c_int
        u.IsIconic.argtypes = [ctypes.c_void_p]
        u.IsWindowVisible.argtypes = [ctypes.c_void_p]
        callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

        def visit(hwnd, _):
            if not hwnd or window_pid(hwnd) in (0, os.getpid()) or is_shell_window(hwnd):
                return True
            if u.IsIconic(hwnd) or not u.IsWindowVisible(hwnd):
                return True
            rect = wintypes.RECT()
            if u.GetWindowRect(hwnd, ctypes.byref(rect)):
                if rect.right - rect.left >= 240 and rect.bottom - rect.top >= 180:
                    windows.append((int(hwnd), (rect.left, rect.top, rect.right, rect.bottom)))
            return True

        callback = callback_type(visit)
        u.EnumWindows.argtypes = [callback_type, ctypes.c_void_p]
        u.EnumWindows.restype = ctypes.c_bool
        u.EnumWindows(callback, None)
    except Exception:
        return []
    return windows


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]


def idle_seconds():
    """Sekunder sedan senaste mus-/tangenttryck."""
    try:
        lii = LASTINPUTINFO()
        lii.cbSize = ctypes.sizeof(LASTINPUTINFO)
        ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lii))
        ctypes.windll.kernel32.GetTickCount.restype = ctypes.c_uint
        return ((ctypes.windll.kernel32.GetTickCount() - lii.dwTime) & 0xFFFFFFFF) / 1000.0
    except Exception:
        return 0.0


def fmt_duration(sec):
    m = int(sec // 60)
    if m < 60:
        return f"{max(1, m)} minutes"
    h = m // 60
    if h < 2:
        return "about an hour"
    if h < 48:
        return f"{h} hours"
    return f"{h // 24} days"


# ---------------- Röst, musik (Windows egna verktyg via PowerShell) ----------------
PS_SPEAK = r"""
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$want = $env:UZI_VOICE
$v = @($s.GetInstalledVoices() | Where-Object { $_.Enabled } | ForEach-Object { $_.VoiceInfo })
$pick = $null
if ($want) { $pick = $v | Where-Object { $_.Name -like "*$want*" } | Select-Object -First 1 }
if (-not $pick) { $pick = $v | Where-Object { $_.Culture.Name -like 'en*' -and $_.Gender -eq 'Female' } | Select-Object -First 1 }
if (-not $pick) { $pick = $v | Where-Object { $_.Culture.Name -like 'en*' } | Select-Object -First 1 }
if ($pick) { $s.SelectVoice($pick.Name) }
$s.Volume = 100
$s.Rate = [int]$env:UZI_RATE
$s.Speak($env:UZI_TEXT)
"""
PS_SPEAK_WAV = PS_SPEAK.replace("$s.Speak($env:UZI_TEXT)",
    "$s.SetOutputToWaveFile($env:UZI_OUT)\n$s.Speak($env:UZI_TEXT)\n$s.SetOutputToNull()\n$s.Dispose()")
PS_LIST = r"""
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name + ' (' + $_.VoiceInfo.Culture.Name + ')' }
"""
PS_MUSIC = r"""
Add-Type -AssemblyName presentationCore
$p = New-Object System.Windows.Media.MediaPlayer
$p.Open([uri]$env:UZI_FILE)
$p.Volume = [double]$env:UZI_VOL
$t0 = Get-Date
while (-not $p.NaturalDuration.HasTimeSpan -and ((Get-Date) - $t0).TotalSeconds -lt 6) { Start-Sleep -Milliseconds 100 }
if ($p.NaturalDuration.HasTimeSpan) {
  $dur = $p.NaturalDuration.TimeSpan.TotalSeconds
  if ($dur -gt 60) { $p.Position = [TimeSpan]::FromSeconds($dur * [double]$env:UZI_START) }
}
$p.Play()
$end = (Get-Date).AddSeconds([double]$env:UZI_SECS)
while ((Get-Date) -lt $end) {
  Start-Sleep -Milliseconds 300
  if ($p.NaturalDuration.HasTimeSpan -and $p.Position -ge $p.NaturalDuration.TimeSpan) { break }
}
$p.Stop()
$p.Close()
"""
NO_WINDOW = 0x08000000


def ps_command(script, extra_env=None, sta=False):
    env = dict(os.environ)
    env.update(extra_env or {})
    args = ["powershell"] + (["-STA"] if sta else []) + ["-NoProfile", "-ExecutionPolicy", "Bypass",
                                                         "-Command", script]
    return dict(args=args, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                creationflags=NO_WINDOW)


def speech_worker():
    global current_proc
    try:
        r = subprocess.run(timeout=60, **ps_command(PS_LIST))
        voices = [v for v in r.stdout.splitlines() if v.strip()]
        print("[voice] installed voices:", voices or "NONE")
        if not any("(en" in v.lower() for v in voices):
            print("[voice] No English voice found - she will speak with the default (non-English) voice.")
    except Exception as e:
        print("[voice] could not list voices:", e)
    while True:
        text = speech_q.get()
        try:
            p = subprocess.Popen(**ps_command(PS_SPEAK, {"UZI_TEXT": text, "UZI_VOICE": VOICE_NAME,
                                                          "UZI_RATE": str(int(VOICE_RATE))}))
            current_proc = p
            _, err = p.communicate(timeout=120)
            if err and err.strip():
                print("[voice] error:", err.strip()[:300])
        except Exception as e:
            print("[voice] error:", e)
        if speech_q.empty():
            time.sleep(0.3)
            speaking.clear()


def stop_speaking():
    try:
        while True:
            speech_q.get_nowait()
    except queue.Empty:
        pass
    p = current_proc
    if p is not None and p.poll() is None:
        try:
            p.kill()
        except Exception:
            pass
    speaking.clear()


# ---------------- Musik (egna filer i mappen "music") ----------------
MUSIC_LINES = [
    "I'm bored. Enjoy some of my music.",
    "Surprise. Music. You're welcome.",
    "This one's mine now. Deal with it.",
    "Sorry, not sorry. Turning this up.",
    "You looked like you needed some background misery.",
    "Don't mind me. Just ruining your concentration.",
]


def music_files():
    try:
        return [os.path.join(MUSIC_DIR, f) for f in os.listdir(MUSIC_DIR)
                if f.lower().endswith(MUSIC_EXT)]
    except Exception:
        return []


def music_playing():
    return music_proc is not None and music_proc.poll() is None


def stop_music():
    p = music_proc
    if p is not None and p.poll() is None:
        try:
            p.kill()
        except Exception:
            pass


def play_music(manual=False):
    """Väljer en slumpad låt och spelar en bit av den. Returnerar True om något startade."""
    global music_proc, music_title, last_song
    files = music_files()
    if not files:
        if manual:
            events.put(("You haven't given me any music. Put some mp3 files in the music folder.", True))
        return False
    stop_music()
    stop_guitar()
    choices = [f for f in files if f != last_song] or files
    path = random.choice(choices)
    last_song = path
    title = os.path.splitext(os.path.basename(path))[0]
    events.put((random.choice(MUSIC_LINES), True))
    time.sleep(0.6)
    t0 = time.time()
    while speaking.is_set() and time.time() - t0 < 10:
        time.sleep(0.2)
    secs = random.randint(*MUSIC_SECS)
    env = {"UZI_FILE": path, "UZI_VOL": str(max(0.05, min(1.0, MUSIC_VOL / 100.0))),
           "UZI_START": f"{random.uniform(0.0, 0.5):.2f}", "UZI_SECS": str(secs)}
    try:
        p = subprocess.Popen(**ps_command(PS_MUSIC, env, sta=True))
    except Exception as e:
        events.put((f"Music problem: {e}", False))
        return False
    music_proc, music_title = p, title
    events.put((f"\u266a {title}", False))

    def watch():
        try:
            _, err = p.communicate()
            if err and err.strip():
                print("[music] error:", err.strip()[:300])
        except Exception:
            pass
    threading.Thread(target=watch, daemon=True).start()
    return True


def music_loop():
    next_at = time.time() + random.uniform(0.5, 1.0) * MUSIC_EVERY * 60
    while True:
        time.sleep(5)
        if time.time() < next_at:
            continue
        if (MUSIC_ENABLED and not music_playing() and not guitar_playing() and not speaking.is_set()
                and not listen_lock.locked() and music_files()):
            try:
                play_music(manual=False)
            except Exception:
                traceback.print_exc()
        next_at = time.time() + random.uniform(0.7, 1.3) * max(1, MUSIC_EVERY) * 60


# ---------------- Gitarr (syntetiserad Karplus-Strong, spelas med winsound) ----------------
GUITAR_LINES = [
    "Fine. Guitar time. Cover your ears.",
    "I wrote this riff at 3 a.m. You're welcome.",
    "Don't clap. I'll know you're lying.",
    "Emo riff incoming. Brace yourself.",
]
GUITAR_TALK = [
    "I play guitar, you know. ...Badly. But loudly.",
    "I could play guitar right now. I won't. Probably.",
    "My guitar's been staring at me all day.",
    "Don't ask me to play. ...Okay, ask me again later.",
    "Everyone says I'm good at guitar. I say they're lying.",
]
PROGRESSIONS = [[40, 48, 43, 50], [45, 41, 48, 43], [40, 43, 50, 45], [38, 46, 41, 48]]  # rot-toner (MIDI)


def note_freq(midi):
    return 440.0 * 2 ** ((midi - 69) / 12.0)


def pluck(freq, dur, sr, decay=0.997):
    """Karplus-Strong: en klippt gitarrsträng (vektoriserad)."""
    n = max(2, int(sr / freq))
    total = max(1, int(sr * dur))
    prev = np.random.uniform(-1, 1, n)
    prev = (prev + np.roll(prev, 1)) / 2
    out = np.empty(total)
    pos = 0
    while pos < total:
        k = min(n, total - pos)
        out[pos:pos + k] = prev[:k]
        prev = decay * 0.5 * (prev + np.roll(prev, 1))
        pos += n
    return out


def make_riff(sr=22050):
    """Skapar ett kort distat powerchord-riff. Returnerar (wav-bytes, sekunder)."""
    bpm = random.choice([84, 96, 108])
    beat = 60.0 / bpm
    chords = random.choice(PROGRESSIONS) * 2
    pattern = random.choice([[0, .5, 1, 1.5], [0, .75, 1, 1.5], [0, .5, .75, 1.5]])
    mix = np.zeros(int(sr * (beat * 2 * len(chords) + 1.8)))
    t = 0.0
    for root in chords:
        for pos in pattern:
            start = int((t + pos * beat) * sr)
            muted = random.random() < 0.25
            for k, semi in enumerate((0, 7, 12)):
                s = pluck(note_freq(root + semi), 0.25 if muted else 1.2, sr, 0.990 if muted else 0.997)
                off = start + int(k * 0.012 * sr)
                end = min(len(mix), off + len(s))
                if end > off:
                    mix[off:end] += s[:end - off] * (0.6 if muted else 1.0)
        t += 2 * beat
    peak = max(1e-6, float(np.max(np.abs(mix))))
    mix = np.tanh(2.5 * mix / peak)
    mix /= max(1e-6, float(np.max(np.abs(mix))))
    fade = int(sr * 0.5)
    mix[-fade:] *= np.linspace(1, 0, fade)
    pcm = (mix * max(0.05, min(1.0, GUITAR_VOL / 100.0)) * 0.8 * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())
    return buf.getvalue(), len(mix) / sr


def guitar_playing():
    return time.time() < guitar_until


def stop_guitar():
    global guitar_until
    guitar_until = 0.0
    try:
        import winsound
        winsound.PlaySound(None, winsound.SND_PURGE)
    except Exception:
        pass


def play_guitar(manual=False):
    global guitar_until, last_guitar_at
    if guitar_playing():
        return False
    stop_music()
    events.put((random.choice(GUITAR_LINES), True))
    time.sleep(0.6)
    t0 = time.time()
    while speaking.is_set() and time.time() - t0 < 10:
        time.sleep(0.2)
    try:
        wav, dur = make_riff()
        with open(GUITAR_WAV, "wb") as f:
            f.write(wav)
        import winsound
        winsound.PlaySound(GUITAR_WAV, winsound.SND_FILENAME | winsound.SND_ASYNC)
    except Exception as e:
        events.put((f"Guitar problem: {e}", False))
        return False
    guitar_until = time.time() + dur
    last_guitar_at = time.time()
    events.put(("\u266b \u266a \u266b", False))
    return True


def guitar_loop():
    next_at = time.time() + random.uniform(0.4, 0.9) * GUITAR_EVERY * 60
    while True:
        time.sleep(5)
        if time.time() < next_at:
            continue
        if (GUITAR_ENABLED and not speaking.is_set() and not music_playing()
                and not guitar_playing() and not listen_lock.locked()):
            try:
                if random.random() < 0.25 and time.time() - last_guitar_at > 20 * 60:
                    play_guitar()
                else:
                    events.put((random.choice(GUITAR_TALK), True))   # hon säger bara att hon spelar gitarr
            except Exception:
                traceback.print_exc()
        next_at = time.time() + random.uniform(0.7, 1.3) * max(1, GUITAR_EVERY) * 60


atexit.register(stop_music)
atexit.register(stop_guitar)
atexit.register(stop_speaking)


# ---------------- Lokal AI via Ollama (text + bild) ----------------
_direct = urllib.request.build_opener(urllib.request.ProxyHandler({}))   # anropen till Ollama ska ALDRIG gå via en proxy
ollama_start_lock = threading.Lock()
last_ollama_start = 0.0


def ollama_up(timeout=2.0):
    try:
        _direct.open(urllib.request.Request(OLLAMA_URL + "/api/tags"), timeout=timeout).read()
        return True
    except Exception:
        return False


def ollama_models():
    try:
        j = json.loads(_direct.open(urllib.request.Request(OLLAMA_URL + "/api/tags"), timeout=5).read())
        return [m.get("name", "") for m in j.get("models", [])]
    except Exception:
        return None


def ollama_exe():
    local = os.environ.get("LOCALAPPDATA", "")
    for c in (os.path.join(local, "Programs", "Ollama", "ollama app.exe"), shutil.which("ollama"),
              os.path.join(local, "Programs", "Ollama", "ollama.exe"), r"C:\Program Files\Ollama\ollama.exe"):
        if c and os.path.exists(c):
            return c
    return None


def ensure_ollama():
    """Svarar inte Ollama försöker Uzi starta den (bara om den ska ligga på den här datorn). True om den svarar."""
    global last_ollama_start
    if ollama_up():
        return True
    if (urllib.parse.urlparse(OLLAMA_URL).hostname or "") not in ("127.0.0.1", "localhost"):
        return False                                     # Ollama ligger på en annan dator - den kan inte vi starta
    with ollama_start_lock:
        if ollama_up():                                  # någon annan tråd hann starta den
            return True
        if time.time() - last_ollama_start < 60:
            return False
        last_ollama_start = time.time()
        exe = ollama_exe()
        if not exe:
            print("[brain] Ollama isn't installed (or I can't find it).")
            return False
        print("[brain] Ollama isn't answering - starting it:", exe)
        try:
            if exe.lower().endswith("ollama app.exe"):
                subprocess.Popen([exe], creationflags=NO_WINDOW)
            else:
                subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 creationflags=NO_WINDOW)
        except Exception as e:
            print("[brain] could not start Ollama:", e)
            return False
        for _ in range(40):                              # upp till ~20 sekunder
            time.sleep(0.5)
            if ollama_up():
                print("[brain] Ollama is up.")
                return True
    return False


def brain_status():
    """Text för panelen/felsökning: svarar Ollama, och finns modellerna?"""
    if not ensure_ollama():
        return (f"Ollama isn't answering at {OLLAMA_URL}. Start Ollama (Start menu), or run Check_brain.bat "
                "to see exactly why.")
    names = ollama_models() or []
    have = lambda want: any(n == want or n == want + ":latest" for n in names)
    if not have(MODEL):
        return f"Ollama is running, but the model is missing. Run in cmd: ollama pull {MODEL}"
    extra = "" if have(VISION_MODEL) else f" (Camera vision needs: ollama pull {VISION_MODEL})"
    return f"Brain OK: Ollama answers and {MODEL} is installed.{extra}"


def brain_watch():
    """Vid start: kolla hjärnan en gång och varna i pratbubblan om något saknas."""
    time.sleep(3)
    msg = brain_status()
    print("[brain]", msg)
    if not msg.startswith("Brain OK"):
        events.put((msg, False))


def _ollama_post(payload, timeout=240):
    req = urllib.request.Request(OLLAMA_URL + "/api/chat", data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    for attempt in (0, 1):
        try:
            with _direct.open(req, timeout=timeout) as r:
                return json.loads(r.read())["message"]["content"].strip()
        except urllib.error.HTTPError:
            raise
        except urllib.error.URLError:
            if attempt == 0 and ensure_ollama():         # Ollama låg nere: starta den och försök en gång till
                continue
            raise


def ollama_chat(messages, max_tokens=120):
    return _ollama_post({
        "model": MODEL, "messages": messages, "stream": False, "keep_alive": "5m",
        "options": {"num_predict": max_tokens, "num_ctx": 2048, "temperature": 0.95, "repeat_penalty": 1.15},
    })


def vision_describe(b64):
    return _ollama_post({
        "model": VISION_MODEL, "stream": False, "keep_alive": "30s",
        "messages": [{"role": "user", "images": [b64], "content":
                      "Describe the person in this image in one or two short sentences: "
                      "how they look, their expression and what they are doing."}],
        "options": {"num_predict": 70, "temperature": 0.2},
    }, timeout=300)


def with_catchphrase(reply):
    """Slänger ibland på hennes catchphrase (som lilla chans, justerbar i panelen)."""
    profile_uses_phrase = (CHARACTER_PRESET == "Uzi"
                           or CATCHPHRASE.lower().rstrip(".") in PERSONALITY_TEXT.lower())
    if (profile_uses_phrase and CATCHPHRASE and CATCHPHRASE_CHANCE > 0
            and CATCHPHRASE.lower().rstrip(".") not in reply.lower()
            and random.random() * 100 < CATCHPHRASE_CHANCE):
        repeats = 2 if random.random() < 0.18 else 1
        reply = reply.rstrip() + " " + " ".join([CATCHPHRASE] * repeats)
    return reply


def ask(user_text, manual=False, raw=None):
    """Returnerar (text, speak). Fel visas alltid vid manuella frågor."""
    global warned_ollama
    msgs = [{"role": "system", "content": system_prompt()}]
    for u, a in history[-6:]:
        msgs.append({"role": "user", "content": u})
        msgs.append({"role": "assistant", "content": a})
    msgs.append({"role": "user", "content": user_text})
    try:
        reply = ollama_chat(msgs)
        warned_ollama = False
    except urllib.error.HTTPError as e:
        err = (f"Model missing. Run in cmd: ollama pull {MODEL}" if e.code == 404
               else f"Ollama error {e.code}.")
    except urllib.error.URLError:
        err = (f"I can't reach my brain. Ollama isn't answering at {OLLAMA_URL}, and I couldn't start it. "
               "Start Ollama, or run Check_brain.bat to find out why.")
    except Exception as e:
        err = f"Brain trouble: {e}"
    else:
        reply = with_catchphrase(reply)
        history.append((raw or user_text, reply))
        del history[:-12]
        if manual and raw:
            remember(raw, reply)
        return (reply, True)
    if manual or not warned_ollama:
        warned_ollama = True
        return (err, False)
    return None


# ---------------- Kamera: hon kan se dig ----------------
def capture_frame_b64():
    import cv2
    cap = cv2.VideoCapture(int(CAM_INDEX), cv2.CAP_DSHOW)
    frame = None
    try:
        if not cap.isOpened():
            raise RuntimeError("I can't open the camera (is another app using it?)")
        for _ in range(8):                       # låt exponeringen hinna ställa in sig
            ok, f = cap.read()
            if ok:
                frame = f
            time.sleep(0.05)
    finally:
        cap.release()
    if frame is None:
        raise RuntimeError("The camera gave me nothing.")
    h, w = frame.shape[:2]
    s = 512.0 / max(h, w)
    if s < 1:
        frame = cv2.resize(frame, (int(w * s), int(h * s)))
    ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 70])
    return base64.b64encode(buf.tobytes()).decode()


def look_at_user(instruction, manual=True):
    """Tar en bild, beskriver den lokalt, och låter Uzi kommentera. Bilden sparas aldrig."""
    global ui_state
    ui_state = "thinking"
    try:
        desc = vision_describe(capture_frame_b64())
        r = ask(f"[Through the webcam you see: {desc}] {instruction}", manual=manual)
        if r:
            events.put(r)
    except ImportError:
        msg = "I can't see: OpenCV is missing. Run in cmd: pip install opencv-python"
        events.put((msg, False)) if manual else print("[camera]", msg)
    except urllib.error.HTTPError as e:
        msg = (f"Vision model missing. Run in cmd: ollama pull {VISION_MODEL}" if e.code == 404
               else f"Vision error {e.code}.")
        events.put((msg, False)) if manual else print("[camera]", msg)
    except urllib.error.URLError:
        msg = "I can't reach my brain. Ollama isn't answering - run Check_brain.bat."
        events.put((msg, False)) if manual else print("[camera]", msg)
    except Exception as e:
        events.put((f"Camera trouble: {e}", False)) if manual else print("[camera]", e)
    finally:
        ui_state = "idle"


def cam_loop():
    time.sleep(60)
    next_at = time.time() + random.uniform(0.5, 1.0) * CAM_EVERY * 60
    while True:
        time.sleep(30)
        if time.time() < next_at:
            continue
        if (CAMERA_ENABLED and CAM_GLANCE and idle_seconds() < 120 and not speaking.is_set()
                and not music_playing() and not guitar_playing() and not listen_lock.locked()):
            look_at_user("Comment briefly, in character, on what you see - as if you weren't watching.",
                         manual=False)
        next_at = time.time() + random.uniform(0.7, 1.3) * max(1, CAM_EVERY) * 60


# ---------------- Saknar dig ----------------
LONELY_LINES = [
    "...hello? Anyone? Not that I care.",
    "It's so quiet. I hate it. Not that I'm lonely.",
    "I'm definitely not waiting for you. I'm just here. Existing.",
    "You left me alone with my thoughts. Terrible idea.",
]


def greet_back(gap, what):
    d = fmt_duration(gap)
    prompt = (f"[The user just came back after {d} ({what}). You missed them a lot but hate admitting it. "
              "React in character in one or two sentences.]")
    r = ask(prompt)
    if r and r[1]:
        events.put(r)
        return
    if gap < 3600:
        lines = ["Oh. You're back. I wasn't waiting or anything.", "Finally. Not that I counted."]
    elif gap < 6 * 3600:
        lines = [f"Where were you? {d}. ...Not that I care.", f"{d} alone. Cool. Totally fine."]
    else:
        lines = [f"{d}?! ...I mean. Whatever. Hi.", "I thought you died. Which would have been inconvenient."]
    events.put((random.choice(lines), True))


def miss_loop():
    time.sleep(8)
    if MISS_ENABLED and startup_last_seen:
        gap = time.time() - float(startup_last_seen)
        if gap > 30 * 60:
            greet_back(gap, "nobody had started her for a while")
    away, away_start, next_lonely, last_save = False, 0.0, 0.0, 0.0
    while True:
        time.sleep(5)
        now = time.time()
        if now - last_save > 60:
            saved["last_seen"] = now
            save_settings()
            last_save = now
        if not MISS_ENABLED:
            away = False
            continue
        idle = idle_seconds()
        if not away and idle >= max(1, MISS_AFTER) * 60:
            away, away_start = True, now - idle
            next_lonely = now + random.uniform(15, 30) * 60
        elif away:
            if idle < 5:                                  # du är tillbaka
                away = False
                threading.Thread(target=greet_back, args=(now - away_start, "away from the computer"),
                                 daemon=True).start()
            elif now >= next_lonely:
                events.put((random.choice(LONELY_LINES), False))   # hon pratar för sig själv (bara text)
                next_lonely = now + random.uniform(20, 40) * 60


# ---------------- PC-kontroll: webbläsare, YouTube, appar ----------------
BROWSER_EXES = {"chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe", "opera_gx.exe", "vivaldi.exe"}
VK = {"ctrl": 0x11, "shift": 0x10, "alt": 0x12, "tab": 0x09, "t": 0x54, "w": 0x57, "f5": 0x74, "win": 0x5B,
      "d": 0x44, "c": 0x43, "v": 0x56, "z": 0x5A, "y": 0x59, "a": 0x41, "left": 0x25, "right": 0x27,
      "vol_up": 0xAF, "vol_down": 0xAE, "vol_mute": 0xAD, "media_pp": 0xB3, "media_next": 0xB0, "media_prev": 0xB1}
EXT_KEYS = {"vol_up", "vol_down", "vol_mute", "media_pp", "media_next", "media_prev", "left", "right"}
SITES = {
    "youtube": "https://www.youtube.com", "google": "https://www.google.com", "github": "https://github.com",
    "reddit": "https://www.reddit.com", "twitter": "https://x.com", "tiktok": "https://www.tiktok.com",
    "gmail": "https://mail.google.com", "wikipedia": "https://www.wikipedia.org",
    "netflix": "https://www.netflix.com", "twitch": "https://www.twitch.tv", "discord": "https://discord.com/app",
    "instagram": "https://www.instagram.com", "facebook": "https://www.facebook.com",
}
_u32 = None


def user32():
    global _u32
    if _u32 is None:
        u = ctypes.windll.user32
        u.GetForegroundWindow.restype = ctypes.c_void_p
        for fn, args in (("SetForegroundWindow", [ctypes.c_void_p]), ("IsIconic", [ctypes.c_void_p]),
                         ("IsWindow", [ctypes.c_void_p]), ("ShowWindow", [ctypes.c_void_p, ctypes.c_int]),
                         ("GetWindowThreadProcessId", [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)])):
            getattr(u, fn).argtypes = args
        u.keybd_event.argtypes = [ctypes.c_ubyte, ctypes.c_ubyte, ctypes.c_ulong, ctypes.c_size_t]
        u.GetClassNameW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_int]
        u.PostMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_ssize_t]
        u.mouse_event.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_size_t]
        _u32 = u
    return _u32


def process_name(hwnd):
    """Programnamn (t.ex. chrome.exe) för ett fönster. Bara namnet läses, inget sparas."""
    try:
        u, k = user32(), ctypes.windll.kernel32
        pid = ctypes.c_ulong(0)
        u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        k.OpenProcess.restype = ctypes.c_void_p
        k.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        h = k.OpenProcess(0x1000, False, pid.value)       # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(520)
            size = ctypes.c_ulong(520)
            k.QueryFullProcessImageNameW.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_wchar_p,
                                                     ctypes.POINTER(ctypes.c_ulong)]
            if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                return os.path.basename(buf.value).lower()
        finally:
            k.CloseHandle.argtypes = [ctypes.c_void_p]
            k.CloseHandle(h)
    except Exception:
        pass
    return ""


def browser_tracker():
    """Kommer ihåg ditt senaste fönster och din senaste webbläsare (bara när PC-kontroll är på)."""
    global last_browser_hwnd, last_window_hwnd
    me = os.getpid()
    while True:
        if PC_CONTROL:
            try:
                hwnd = user32().GetForegroundWindow()
                if hwnd and window_pid(hwnd) not in (0, me) and not is_shell_window(hwnd):
                    last_window_hwnd = hwnd
                    if process_name(hwnd) in BROWSER_EXES:
                        last_browser_hwnd = hwnd
            except Exception:
                pass
        time.sleep(0.7)


def focus_browser():
    """Sätter fokus på din senaste webbläsare. Returnerar True om det lyckades."""
    return focus_hwnd(last_browser_hwnd)


def press(*keys):
    u = user32()
    for k in keys:
        u.keybd_event(VK[k], 0, 1 if k in EXT_KEYS else 0, 0)
    for k in reversed(keys):
        u.keybd_event(VK[k], 0, (1 if k in EXT_KEYS else 0) | 2, 0)
    time.sleep(0.05)


_PREFIX = re.compile(r"^\s*(?:(?:hey|ok|okay|please|uzi|can you|could you|would you|will you|i want you to|"
                     r"i need you to|go ahead and|just|now)\s+)+")
NUMWORDS = {"a": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5}


def parse_pc_command(text):
    """Tolkar en mening som ett PC-kommando. Returnerar (typ, argument) eller None.
    Kommandot måste stå först i meningen (efter t.ex. 'uzi can you'), så vanligt prat missförstås inte."""
    t = re.sub(r"[^\w\s.'-]", " ", text.lower())
    t = re.sub(r"\s+", " ", t).strip()
    core = _PREFIX.sub("", t + " ").strip()
    core = re.sub(r"\s+(?:please|now|for me|thanks|thank you)$", "", core)
    if not core:
        return None

    if re.search(r"\b(spotify|playlist|queue)\b", core):
        m = re.match(r"(?:add|put|save)\s+(.+?)\s+(?:to|on|in|into)\s+(?:my\s+|the\s+)?(spotify|playlist|queue)\b"
                     r"(?:\s+playlist)?(?:\s+(?:called|named)\s+(.+))?$", core)
        if m:
            song, where, pl = m.group(1), m.group(2), m.group(3)
            return ("sp_queue", song) if where == "queue" else ("sp_add", (song, pl))
        m = re.match(r"(?:add|put|save)\s+(.+?)\s+(?:to|on|in|into)\s+(?:my\s+|the\s+)(.+?)\s+playlist$", core)
        if m and m.group(2) != "spotify":
            return ("sp_add", (m.group(1), m.group(2)))
        m = re.match(r"queue(?:\s+up)?\s+(.+?)(?:\s+on spotify)?$", core)
        if m:
            return ("sp_queue", m.group(1))
        m = re.match(r"play\s+(.+?)\s+on\s+spotify$", core)
        if m:
            return ("sp_play", m.group(1))
        if re.match(r"(?:open|launch|start)\s+spotify$", core):
            return ("app_spotify", None)
        m = re.search(r"\b(pause|resume|skip|next|previous|back)\b", core)
        if "spotify" in core and m:
            return ("sp_ctl", m.group(1))

    m = (re.match(r"(?:play|search|find|look up|watch|show me)\s+(.+?)\s+(?:on|in|at)\s+youtube$", core)
         or re.match(r"youtube\s+(?:search|for)\s+(.+)$", core)
         or re.match(r"search\s+youtube\s+for\s+(.+)$", core))
    if m:
        return ("yt", m.group(1))
    if re.match(r"(?:go to|open|take me to|show me|visit)\s+youtube$", core):
        return ("url", SITES["youtube"])

    m = re.match(r"close\b(.*?)\btabs?$", core)
    if m and len(m.group(1)) < 30:
        mid = m.group(1).split()
        if "all" in mid or "every" in mid:
            return ("tab_refuse", None)
        n = (next((int(w) for w in mid if w.isdigit()), None)
             or next((NUMWORDS[w] for w in mid if w in NUMWORDS), 1))
        return ("tab_close", max(1, min(5, n)))
    if re.match(r"(?:(?:open|make|create)\s+)?(?:a\s+)?new\s+tab$", core):
        return ("tab_new", None)
    if re.match(r"(?:(?:go to|switch to)\s+)?(?:the\s+)?next\s+tab$", core):
        return ("tab_next", None)
    if re.match(r"(?:(?:go to|switch to)\s+)?(?:the\s+)?(?:previous|prev|last)\s+tab$", core):
        return ("tab_prev", None)
    if re.match(r"(?:reopen|restore|bring back)\s+(?:the\s+|that\s+|my\s+)?(?:last\s+|closed\s+)?tab$", core):
        return ("tab_reopen", None)
    if re.match(r"(?:refresh|reload)(?:\s+(?:the|this))?(?:\s+(?:page|tab|site))?$", core):
        return ("tab_refresh", None)

    # --- avancerat: volym, media, fönster, skärm, mappar, skriva ---
    def vol(direction, word=""):
        amt = 2 if word in ("a bit", "a little", "slightly") else 15 if word in ("a lot", "all the way") else 5
        return ("pc_volume", (direction, amt))
    m = re.match(r"(?:turn|make|put)?\s*(?:the |my )?(?:volume|sound)\s+(up|down)"
                 r"(?:\s+(a bit|a little|a lot|slightly|all the way))?$", core)
    if m:
        return vol(m.group(1), m.group(2) or "")
    m = re.match(r"turn\s+(up|down)\s+(?:the\s+)?(?:volume|sound)(?:\s+(a bit|a little|a lot|slightly))?$", core)
    if m:
        return vol(m.group(1), m.group(2) or "")
    m = re.match(r"(?:turn|make)\s+(?:it|this|the volume|the sound)\s+(up|down|louder|quieter)"
                 r"(?:\s+(a bit|a little|a lot|slightly))?$", core)
    if m:
        return vol("up" if m.group(1) in ("up", "louder") else "down", m.group(2) or "")
    m = re.match(r"(?:make it\s+)?(louder|quieter)$", core)
    if m:
        return vol("up" if m.group(1) == "louder" else "down")
    if re.match(r"(?:mute|unmute)(?:\s+(?:the\s+)?(?:sound|volume|pc|computer))?$", core):
        return ("pc_volume", ("mute", 1))
    if re.match(r"(?:pause|resume|play|stop)(?:\s+the)?\s+(?:video|media|movie|youtube|netflix)$", core):
        return ("pc_media", "playpause")
    if re.match(r"(?:next|skip)(?:\s+the)?\s+(?:track|video)$", core):
        return ("pc_media", "next")
    if re.match(r"(?:previous|last)\s+(?:track|video)$", core):
        return ("pc_media", "prev")
    if re.match(r"(?:(?:show|go to)\s+(?:the\s+)?desktop|minimi[sz]e\s+(?:everything|all(?:\s+windows)?))$", core):
        return ("pc_desktop", None)
    if re.match(r"minimi[sz]e(?:\s+(?:this|the))?(?:\s+(?:window|app|program))?$", core):
        return ("pc_minimize", None)
    if re.match(r"maximi[sz]e(?:\s+(?:this|the))?(?:\s+(?:window|app|program))?$", core):
        return ("pc_maximize", None)
    if re.match(r"close\s+(?:this|the|that)\s+(?:window|app|program)$", core):
        return ("pc_close", None)
    if re.match(r"(?:switch\s+(?:windows?|apps?)|alt\s*tab)$", core):
        return ("pc_switch", None)
    if re.match(r"lock(?:\s+(?:the|my))?(?:\s+(?:pc|computer|screen))?$", core):
        return ("pc_lock", None)
    if re.match(r"(?:put\s+(?:the|my)\s+(?:pc|computer)\s+(?:to\s+)?sleep|sleep\s+(?:the\s+)?(?:pc|computer))$", core):
        return ("pc_sleep", None)
    if re.match(r"(?:shut\s?down|power\s+off|turn\s+off)(?:\s+(?:the|my))?\s+(?:pc|computer)$", core):
        return ("pc_shutdown", None)
    if re.match(r"(?:restart|reboot)(?:\s+(?:the|my))?\s+(?:pc|computer)$", core):
        return ("pc_restart", None)
    if re.match(r"cancel\s+(?:the\s+)?(?:shut\s?down|restart|reboot)$", core):
        return ("pc_cancel", None)
    if re.match(r"(?:(?:take|grab|make)\s+(?:a\s+)?)?screenshot$", core):
        return ("pc_screenshot", None)
    m = re.match(r"scroll\s+(up|down)(?:\s+(a\s+bit|a\s+little|a\s+lot))?$", core)
    if m:
        return ("pc_scroll", (m.group(1), 10 if m.group(2) == "a lot" else 2 if m.group(2) else 4))
    m = re.match(r"open\s+(?:my\s+|the\s+)?(downloads|documents|desktop|pictures|music|videos)(?:\s+folder)?$", core)
    if m:
        return ("pc_folder", m.group(1))
    m = re.match(r"(copy|paste|undo|redo|select all)(?:\s+(?:that|this|it))?$", core)
    if m:
        return ("pc_key", m.group(1))
    if core.startswith("type "):
        orig = re.sub(r"^\s*(?:(?:hey|ok|okay|please|uzi|can you|could you|would you|will you|i want you to|"
                      r"i need you to|go ahead and|just|now)[\s,]+)+", "", text.strip(), flags=re.I)
        m = re.match(r"type(?:\s+out)?\s+(.+)$", orig, re.I)
        if m:
            return ("pc_type", m.group(1).strip())

    m = re.match(r"(?:go to|open|take me to|visit)\s+(?:the\s+)?(?:website\s+)?"
                 r"([a-z0-9-]+\.(?:com|se|org|net|io|tv|gg|app|dev))$", core)
    if m:
        return ("url", "https://" + m.group(1))
    m = re.match(r"(?:go to|open|take me to|visit)\s+(?:the\s+)?(youtube|google|github|reddit|twitter|tiktok|gmail|"
                 r"wikipedia|netflix|twitch|discord|instagram|facebook)(?:\s+dot com)?$", core)
    if m:
        return ("url", SITES[m.group(1)])
    m = re.match(r"(?:google|search for|search the web for|search google for)\s+(.+)$", core)
    if m:
        return ("google", m.group(1))
    if PC_FULL:                                             # "open Discord" - bara när avancerad kontroll är på
        m = re.match(r"(?:open|launch|start)\s+(?:the\s+)?(.+?)(?:\s+(?:app|application|program))?$", core)
        if m and not re.match(r"(?:up|over|again|talking|playing|a|an|my|your)\b", m.group(1)):
            return ("app", m.group(1))
    return None


def run_tab_action(kind, arg, say):
    if kind == "tab_refuse":
        say("I'm not closing all your tabs. Give me a number up to five.")
        return
    if not focus_browser():
        say("I can't find a browser window. Open one first.")
        return
    if kind == "tab_close":
        for _ in range(int(arg)):
            press("ctrl", "w")
            time.sleep(0.35)
        say("Closed." if int(arg) == 1 else f"Closed {arg} tabs.")
    elif kind == "tab_new":
        press("ctrl", "t")
        say("New tab. Thrilling.")
    elif kind == "tab_next":
        press("ctrl", "tab")
        say("Next tab.")
    elif kind == "tab_prev":
        press("ctrl", "shift", "tab")
        say("Previous tab.")
    elif kind == "tab_reopen":
        press("ctrl", "shift", "t")
        say("Brought it back. You're welcome.")
    elif kind == "tab_refresh":
        press("f5")
        say("Refreshed.")


# ---------------- Avancerad PC-kontroll (appar, volym, fönster, skriva, avstängning - med bekräftelse) ----------------
CONFIRM_KINDS = {"pc_close": "Close that window", "pc_sleep": "Put the PC to sleep",
                 "pc_shutdown": "Shut the PC down", "pc_restart": "Restart the PC"}
BLOCKED_APPS = ("cmd", "command prompt", "powershell", "terminal", "regedit", "registry", "services",
                "computer management", "group policy", "task scheduler", "event viewer")
APP_ALIASES = {"notepad": "notepad", "calculator": "calc", "paint": "mspaint", "settings": "ms-settings:",
               "task manager": "taskmgr", "file explorer": "explorer", "explorer": "explorer",
               "snipping tool": "snippingtool", "camera": "microsoft.windows.camera:", "clock": "ms-clock:",
               "store": "ms-windows-store:"}
FOLDERS = {"downloads": "Downloads", "documents": "Documents", "desktop": "Desktop", "pictures": "Pictures",
           "music": "Music", "videos": "Videos"}
KEY_COMBOS = {"copy": ("ctrl", "c"), "paste": ("ctrl", "v"), "undo": ("ctrl", "z"), "redo": ("ctrl", "y"),
              "select all": ("ctrl", "a")}
YES_RE = re.compile(r"^\W*(?:yes|yeah|yep|yup|sure|ok|okay|do it|go ahead|confirm|please do)\b", re.I)
NO_RE = re.compile(r"^\W*(?:no|nope|nah|cancel|stop|never ?mind|don'?t|abort)\b", re.I)
_app_index = {"t": 0.0, "apps": {}}


def log_action(kind, arg, phone):
    """Allt hon gör på datorn skrivs i uzi_actions.log (skrivna texter loggas bara som antal tecken)."""
    try:
        shown = f"<{len(str(arg))} chars>" if kind == "pc_type" else arg
        with open(ACTION_LOG, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {'phone' if phone else 'pc'} {kind} {shown}\n")
    except Exception:
        pass


def window_pid(hwnd):
    try:
        pid = ctypes.c_ulong(0)
        user32().GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return pid.value
    except Exception:
        return 0


def is_shell_window(hwnd):
    try:
        buf = ctypes.create_unicode_buffer(256)
        user32().GetClassNameW(hwnd, buf, 256)
        return buf.value in ("Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd")
    except Exception:
        return False


def window_title(hwnd):
    try:
        n = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        ctypes.windll.user32.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value.strip()[:60]
    except Exception:
        return ""


def focus_hwnd(hwnd):
    try:
        u = user32()
        if not hwnd or not u.IsWindow(hwnd):
            return False
        if u.IsIconic(hwnd):
            u.ShowWindow(hwnd, 9)
        u.keybd_event(VK["alt"], 0, 0, 0)                 # ALT-tryck gör att Windows släpper igenom fokusbytet
        u.keybd_event(VK["alt"], 0, 2, 0)
        u.SetForegroundWindow(hwnd)
        time.sleep(0.3)
        return u.GetForegroundWindow() == hwnd
    except Exception:
        return False


def focus_last_window():
    return focus_hwnd(last_window_hwnd)


class _KI(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort), ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.c_size_t)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("ki", _KI), ("pad", ctypes.c_ubyte * 32)]


class _INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", ctypes.c_ulong), ("u", _INPUTUNION)]


def send_text(text):
    """Skriver text som tangenttryck (Unicode). Trycker aldrig Enter."""
    u = user32()
    u.SendInput.argtypes = [ctypes.c_uint, ctypes.POINTER(_INPUT), ctypes.c_int]
    clean = re.sub(r"[\r\n\t]+", " ", text)[:200]
    units = struct.unpack(f"<{len(clean.encode('utf-16-le')) // 2}H", clean.encode("utf-16-le"))
    for unit in units:
        for flags in (0x0004, 0x0004 | 0x0002):           # KEYEVENTF_UNICODE: ner, upp
            inp = _INPUT()
            inp.type = 1
            inp.ki.wScan = unit
            inp.ki.dwFlags = flags
            u.SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))
        time.sleep(0.01)


def scroll_wheel(direction, notches):
    u = user32()
    for _ in range(notches):
        u.mouse_event(0x0800, 0, 0, ((120 if direction == "up" else -120) & 0xFFFFFFFF), 0)
        time.sleep(0.03)


def build_app_index():
    if time.time() - _app_index["t"] < 600 and _app_index["apps"]:
        return _app_index["apps"]
    apps = {}
    for root in (os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), r"Microsoft\Windows\Start Menu\Programs"),
                 os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs")):
        for dp, _dn, files in os.walk(root):
            for f in files:
                name = os.path.splitext(f)[0]
                if f.lower().endswith((".lnk", ".url")) and "uninstall" not in name.lower():
                    apps.setdefault(name.lower(), os.path.join(dp, f))
    _app_index.update(t=time.time(), apps=apps)
    return apps


def find_app(query):
    """Returnerar (visningsnamn, sökväg), ("blocked", None) eller None."""
    q = re.sub(r"\s+", " ", query.lower()).strip()
    if not q:
        return None
    if any(re.search(rf"\b{re.escape(b)}\b", q) for b in BLOCKED_APPS):
        return ("blocked", None)
    if q in APP_ALIASES:
        return (q, APP_ALIASES[q])
    apps = build_app_index()
    if q in apps:
        return (q, apps[q])
    for pool in ([n for n in apps if n.startswith(q)], [n for n in apps if q in n]):
        if pool:
            n = min(pool, key=len)
            return (n, apps[n])
    return None


def run_adv_action(kind, arg, say, phone=False, confirmed=False):
    if kind == "pc_cancel":                               # avbryta avstängning ska alltid fungera
        subprocess.run(["shutdown", "/a"], capture_output=True, creationflags=NO_WINDOW)
        log_action(kind, arg, phone)
        say("Cancelled. You're welcome.")
        return
    if not PC_FULL:
        say("Advanced PC control is off. Turn it on in the PC control tab if you really want me to do that.")
        return
    if kind in CONFIRM_KINDS and not confirmed:
        what = CONFIRM_KINDS[kind]
        if kind == "pc_close":
            title = window_title(last_window_hwnd) if last_window_hwnd else ""
            what += f" \"{title}\"" if title else ""
        pending_confirm.clear()
        pending_confirm.update(kind=kind, arg=arg, phone=phone, expires=time.time() + 15)
        say(f"{what}? Say yes within 15 seconds.")
        return
    log_action(kind, arg, phone)
    u = user32()
    if kind == "pc_volume":
        direction, amount = arg
        if direction == "mute":
            press("vol_mute")
            say("Muted. Or unmuted. Whichever it wasn't.")
        else:
            for _ in range(int(amount)):
                press("vol_up" if direction == "up" else "vol_down")
            say("Louder. Your neighbors will love me." if direction == "up" else "Quieter. Finally.")
    elif kind == "pc_media":
        press({"playpause": "media_pp", "next": "media_next", "prev": "media_prev"}[arg])
        say("Done.")
    elif kind == "pc_desktop":
        press("win", "d")
        say("Everything's hidden. Like my feelings.")
    elif kind in ("pc_minimize", "pc_maximize", "pc_close"):
        hwnd = last_window_hwnd
        if not hwnd or not u.IsWindow(hwnd):
            say("I don't know which window you mean. Click on it first.")
            return
        if kind == "pc_minimize":
            u.ShowWindow(hwnd, 6)
            say("Minimized.")
        elif kind == "pc_maximize":
            u.ShowWindow(hwnd, 3)
            say("Maximized.")
        else:
            u.PostMessageW(hwnd, 0x0010, 0, 0)           # WM_CLOSE: appar frågar själva om du vill spara
            say("Closed it. Or asked it nicely to close, anyway.")
    elif kind == "pc_switch":
        press("alt", "tab")
        say("Switched.")
    elif kind == "pc_lock":
        u.LockWorkStation()
        say("Locked.")
    elif kind == "pc_sleep":
        say("Night night.")
        time.sleep(1.5)
        subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"], creationflags=NO_WINDOW)
    elif kind in ("pc_shutdown", "pc_restart"):
        subprocess.run(["shutdown", "/s" if kind == "pc_shutdown" else "/r", "/t", "30"],
                       capture_output=True, creationflags=NO_WINDOW)
        say("Going down in 30 seconds. Say cancel shutdown to stop it.")
    elif kind == "pc_screenshot":
        from PIL import ImageGrab
        folder = os.path.join(os.path.expanduser("~"), "Pictures", "Uzi")
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, time.strftime("screenshot-%Y%m%d-%H%M%S.png"))
        ImageGrab.grab(all_screens=True).save(path)
        say("Screenshot saved in your Pictures, Uzi folder.")
    elif kind == "pc_scroll":
        direction, notches = arg
        scroll_wheel(direction, notches)
        say("Scrolled.")
    elif kind == "pc_folder":
        os.startfile(os.path.join(os.path.expanduser("~"), FOLDERS[arg]))
        say(f"Opening {arg}.")
    elif kind == "pc_type":
        if not focus_last_window():
            say("I can't find the window to type into. Click on it first.")
            return
        send_text(arg)
        say("Typed it. I didn't press Enter. You do that.")
    elif kind == "pc_key":
        if not focus_last_window():
            say("I can't find the window. Click on it first.")
            return
        press(*KEY_COMBOS[arg])
        say("Done.")
    elif kind == "app":
        found = find_app(arg)
        if found is None:
            say(f"I can't find an app called {arg}.")
        elif found[0] == "blocked":
            say("Nope. I don't open terminals or system tools. That's how things get deleted.")
        else:
            os.startfile(found[1])
            say(f"Opening {found[0].title()}.")


def run_pc_action(kind, arg, say, phone=False, confirmed=False):
    """Utför ett PC-kommando. `say(text)` får svaret. Kräver att PC-kontroll är påslaget."""
    if not PC_CONTROL and kind != "pc_cancel":
        say("PC control is off. Turn it on in the PC control tab of my control panel.")
        return
    if phone and not PHONE_CONTROL and kind != "pc_cancel":
        say("I'm not allowed to do that when you ask from your phone. Turn that on in the PC control tab.")
        return
    adv = kind == "app" or kind.startswith("pc_")
    if not adv:
        log_action(kind, arg, phone)
    try:
        if adv:
            run_adv_action(kind, arg, say, phone, confirmed)
        elif kind == "url":
            webbrowser.open(arg, new=2)
            say(random.choice(["Fine. Opening it.", "Opening. Don't blame me for the ads."]))
        elif kind == "yt":
            webbrowser.open("https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(arg), new=2)
            say(f"Searching YouTube for {arg}. You pick the video. I'm not your butler.")
        elif kind == "google":
            webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote_plus(arg), new=2)
            say(f"Googling {arg}. Wow. Groundbreaking.")
        elif kind == "app_spotify":
            os.startfile("spotify:")
            say("Opening Spotify.")
        elif kind.startswith("tab_"):
            run_tab_action(kind, arg, say)
        elif kind.startswith("sp_"):
            say(run_spotify_action(kind, arg))
    except SpotifyError as e:
        say(str(e))
    except urllib.error.URLError:
        say("I can't reach the internet right now.")
    except Exception as e:
        say(f"That didn't work: {e}")


# ---------------- Spotify (egen app på developer.spotify.com, PKCE-inloggning) ----------------
SPOTIFY_REDIRECT = "http://127.0.0.1:8888/callback"
SPOTIFY_SCOPES = ("user-modify-playback-state user-read-playback-state "
                  "playlist-modify-private playlist-modify-public playlist-read-private")
spotify_connecting = False


class SpotifyError(Exception):
    def __init__(self, message, reason=""):
        super().__init__(message)
        self.reason = reason


def spotify_load():
    try:
        with open(SPOTIFY_PATH, encoding="utf-8") as f:
            spotify.update(json.load(f))
    except Exception:
        pass


def spotify_save():
    try:
        with open(SPOTIFY_PATH, "w", encoding="utf-8") as f:
            json.dump(spotify, f)
    except Exception:
        pass


def spotify_connected():
    return bool(spotify.get("refresh"))


def spotify_disconnect():
    spotify.update(access="", refresh="", expires=0.0)
    spotify_save()


def _spotify_token_request(form):
    req = urllib.request.Request("https://accounts.spotify.com/api/token",
                                 data=urllib.parse.urlencode(form).encode(),
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read())


def spotify_connect(status):
    """Loggar in via webbläsaren (Authorization Code + PKCE). Körs i en tråd. status(text) rapporterar."""
    global spotify_connecting
    cid = SPOTIFY_CLIENT_ID.strip()
    if not cid:
        status("Paste your Spotify Client ID first.")
        return
    if spotify_connecting:
        status("Already waiting for you to approve in the browser.")
        return
    spotify_connecting = True
    try:
        verifier = secrets.token_urlsafe(64)[:100]
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
        state = secrets.token_urlsafe(12)
        result = {}

        class Callback(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                if parsed.path != "/callback":
                    self.send_response(404)
                    self.end_headers()
                    return
                q = urllib.parse.parse_qs(parsed.query)
                result.update(code=(q.get("code") or [""])[0], state=(q.get("state") or [""])[0],
                              error=(q.get("error") or [""])[0])
                body = (b"<html><body style='font-family:sans-serif;background:#140b20;color:#f2e6ff;"
                        b"text-align:center;padding-top:80px'><h2>Uzi is connected to Spotify.</h2>"
                        b"<p>You can close this tab.</p></body></html>")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        try:
            srv = http.server.HTTPServer(("127.0.0.1", 8888), Callback)
        except OSError as e:
            status(f"Port 8888 is busy ({e}). Close whatever uses it and try again.")
            return
        srv.timeout = 30
        webbrowser.open("https://accounts.spotify.com/authorize?" + urllib.parse.urlencode({
            "response_type": "code", "client_id": cid, "scope": SPOTIFY_SCOPES, "redirect_uri": SPOTIFY_REDIRECT,
            "state": state, "code_challenge_method": "S256", "code_challenge": challenge}))
        status("Approve Uzi in the browser window that just opened...")
        t0 = time.time()
        while not result and time.time() - t0 < 180:
            srv.handle_request()
        srv.server_close()
        if not result or result.get("error") or not result.get("code"):
            status("Spotify connection cancelled or timed out.")
            return
        if result["state"] != state:
            status("Spotify's answer didn't match. Try again.")
            return
        try:
            tok = _spotify_token_request({
                "grant_type": "authorization_code", "code": result["code"], "redirect_uri": SPOTIFY_REDIRECT,
                "client_id": cid, "code_verifier": verifier})
        except urllib.error.HTTPError as e:
            status(f"Spotify said no ({e.code}): {e.read()[:200].decode('utf-8', 'replace')}")
            return
        spotify.update(access=tok["access_token"], refresh=tok.get("refresh_token", ""),
                       expires=time.time() + tok.get("expires_in", 3600) - 30)
        spotify_save()
        status("Connected to Spotify!")
    except Exception as e:
        status(f"Spotify login failed: {e}")
    finally:
        spotify_connecting = False


def spotify_token():
    if not spotify_connected():
        raise SpotifyError("Spotify isn't connected. Connect it in the PC control tab.")
    if time.time() >= spotify.get("expires", 0):
        tok = _spotify_token_request({"grant_type": "refresh_token", "refresh_token": spotify["refresh"],
                                      "client_id": SPOTIFY_CLIENT_ID.strip()})
        spotify["access"] = tok["access_token"]
        spotify["expires"] = time.time() + tok.get("expires_in", 3600) - 30
        if tok.get("refresh_token"):
            spotify["refresh"] = tok["refresh_token"]
        spotify_save()
    return spotify["access"]


def spotify_api(method, path, params=None, body=None):
    url = "https://api.spotify.com/v1" + path + ("?" + urllib.parse.urlencode(params) if params else "")
    data = json.dumps(body).encode() if body is not None else (b"" if method in ("POST", "PUT") else None)
    for attempt in (0, 1):
        req = urllib.request.Request(url, data=data, method=method, headers={
            "Authorization": "Bearer " + spotify_token(), "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                raw = r.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            if e.code == 401 and attempt == 0:
                spotify["expires"] = 0                      # tvinga ny token och försök igen
                continue
            try:
                err = json.loads(e.read()).get("error", {})
            except Exception:
                err = {}
            msg = err.get("message", "") if isinstance(err, dict) else str(err)
            reason = err.get("reason", "") if isinstance(err, dict) else ""
            if e.code == 401:
                raise SpotifyError("Spotify login expired. Reconnect it in the PC control tab.", reason)
            if e.code == 403:
                raise SpotifyError("Spotify said no (403). Playback control needs Premium, and the account that "
                                   "made the app needs Premium too.", reason)
            if e.code == 404 and reason == "NO_ACTIVE_DEVICE":
                raise SpotifyError("Spotify isn't running anywhere. Open Spotify and play something once.", reason)
            if e.code == 429:
                raise SpotifyError("Spotify says I'm going too fast. Try again in a minute.", reason)
            raise SpotifyError(f"Spotify error {e.code}: {msg}", reason)


def spotify_with_device(method, path, params=None, body=None):
    """Uppspelningsanrop. Finns ingen aktiv enhet försöker Uzi starta Spotify och använda första enheten."""
    try:
        return spotify_api(method, path, params, body)
    except SpotifyError as e:
        if e.reason != "NO_ACTIVE_DEVICE":
            raise

    def devices():
        d = (spotify_api("GET", "/me/player/devices") or {}).get("devices") or []
        return [x for x in d if x.get("id")]
    devs = devices()
    if not devs:
        try:
            os.startfile("spotify:")
        except Exception:
            pass
        for _ in range(10):
            time.sleep(1)
            devs = devices()
            if devs:
                break
    if not devs:
        raise SpotifyError("Spotify isn't running anywhere. Open Spotify on your PC and play something once.",
                           "NO_ACTIVE_DEVICE")
    p = dict(params or {})
    p["device_id"] = devs[0]["id"]
    return spotify_api(method, path, p, body)


def spotify_find(query):
    q = re.sub(r"\s+by\s+", " ", query.strip())
    j = spotify_api("GET", "/search", {"q": q, "type": "track", "limit": 5})
    items = (j.get("tracks") or {}).get("items") or []
    if not items:
        raise SpotifyError(f"I couldn't find {query} on Spotify.")
    t = items[0]
    return t["uri"], f"{t['name']} by {', '.join(a['name'] for a in t.get('artists', [])[:2])}"


def spotify_playlist_id(name, create):
    want = name.strip().lower()
    best = None
    offset = 0
    while offset < 200:
        j = spotify_api("GET", "/me/playlists", {"limit": 50, "offset": offset})
        items = j.get("items") or []
        for p in items:
            if not p:
                continue
            pn = (p.get("name") or "").lower()
            if pn == want:
                return p["id"]
            if want in pn and best is None:
                best = p["id"]
        if len(items) < 50:
            break
        offset += 50
    if best:
        return best
    if not create:
        raise SpotifyError(f"I can't find a playlist called {name}.")
    j = spotify_api("POST", "/me/playlists", body={"name": name, "public": False,
                                                    "description": "Picked by Uzi. You're welcome."})
    return j["id"]


def spotify_add(query, playlist=None):
    uri, name = spotify_find(query)
    default = (SPOTIFY_PLAYLIST or "Uzi picks").strip() or "Uzi picks"
    pname = (playlist or default).strip()
    pid = spotify_playlist_id(pname, create=(pname.lower() == default.lower()))
    spotify_api("POST", f"/playlists/{pid}/items", body={"uris": [uri]})
    return f"Added {name} to {pname}."


def spotify_queue(query):
    uri, name = spotify_find(query)
    spotify_with_device("POST", "/me/player/queue", {"uri": uri})
    return f"Queued {name}."


def spotify_play(query):
    uri, name = spotify_find(query)
    spotify_with_device("PUT", "/me/player/play", body={"uris": [uri]})
    return f"Playing {name}."


def spotify_ctl(word):
    if word == "pause":
        spotify_api("PUT", "/me/player/pause")
        return "Paused. Finally."
    if word in ("resume", "play"):
        spotify_with_device("PUT", "/me/player/play")
        return "Resuming."
    if word in ("skip", "next"):
        spotify_api("POST", "/me/player/next")
        return "Skipped."
    spotify_api("POST", "/me/player/previous")
    return "Going back."


def run_spotify_action(kind, arg):
    if kind == "sp_add":
        return spotify_add(arg[0], arg[1])
    if kind == "sp_queue":
        return spotify_queue(arg)
    if kind == "sp_play":
        return spotify_play(arg)
    if kind == "sp_ctl":
        return spotify_ctl(arg)
    return "I don't know how to do that on Spotify."


# ---------------- Kommandon ----------------
CAM_WORDS = ("look at me", "can you see me", "do you see me", "what do i look like", "what am i wearing",
             "what am i holding", "what am i doing", "how do i look")


def handle_commands(text, phone=False, out=None):
    """Röst-/textkommandon. Returnerar True om texten hanterades.
    Vid phone=True samlas svaren i listan `out` (de skickas till mobilen i stället för att läsas upp på PC:n)."""
    def say(m):
        if phone and out is not None:
            out.append(m)
        else:
            events.put((m, True))

    t = text.lower()
    if pending_confirm:                                         # väntar på "yes" efter t.ex. "shut down the PC"
        if time.time() > pending_confirm["expires"]:
            pending_confirm.clear()
        elif bool(pending_confirm["phone"]) == bool(phone) and (YES_RE.match(text) or NO_RE.match(text)):
            kind, arg, yes = pending_confirm["kind"], pending_confirm["arg"], bool(YES_RE.match(text))
            pending_confirm.clear()
            if not yes:
                say("Fine. Cancelled.")
            elif phone:
                run_pc_action(kind, arg, say, phone=True, confirmed=True)
            else:
                threading.Thread(target=run_pc_action, args=(kind, arg, say), kwargs={"confirmed": True},
                                 daemon=True).start()
            return True
    act = parse_pc_command(text)
    if act:
        kind, arg = act
        if phone:
            run_pc_action(kind, arg, say, phone=True)          # direkt, så svaret hinner med till mobilen
        else:
            threading.Thread(target=run_pc_action, args=(kind, arg, say), daemon=True).start()
        return True
    lead = r"^\W*(?:(?:hey|ok|okay|please|uzi|can you|could you|go ahead and|just|now)[\s,]+)*"
    if re.match(lead + r"(?:sit down|take a seat|have a seat|go sit(?: down)?|sit on (?:the|your) couch)\b", t):
        request_sit()
        say("Fine. Couch time." if COUCH_ENABLED else "I'd sit, but someone turned my couch off.")
        return True
    if re.match(lead + r"(?:stand up|get up|get off (?:the|your) couch)\b", t):
        request_stand()
        say("Ugh. Fine.")
        return True
    stop_words = ("stop", "turn off", "shut", "quiet", "enough", "no more", "pause")
    play_words = ("play", "put on", "start", "turn on")
    about_music = any(w in t for w in ("music", "song", "tune"))
    about_guitar = "guitar" in t
    busy = music_playing() or guitar_playing()
    if any(w in t for w in stop_words) and (about_music or about_guitar or busy):
        stop_music()
        stop_guitar()
        say("Fine. Silence. My favorite sound." if busy else
            "There's nothing playing. I'm just like this naturally.")
        return True
    if about_guitar and any(w in t for w in play_words + ("riff", "strum", "show me")):
        threading.Thread(target=play_guitar, kwargs={"manual": True}, daemon=True).start()
        if phone:
            say("Fine. Guitar. On your PC.")
        return True
    if about_music and any(w in t for w in play_words):
        threading.Thread(target=play_music, kwargs={"manual": True}, daemon=True).start()
        if phone:
            say("Fine. Music. On your PC.")
        return True
    if not phone and any(w in t for w in CAM_WORDS):
        if CAMERA_ENABLED:
            threading.Thread(target=look_at_user,
                             args=(f"The user asked: \"{text}\". Answer based on what you see.",),
                             daemon=True).start()
        else:
            say("My camera access is off. Turn it on in the control panel if you want me to stare at you.")
        return True
    return False


# ---------------- Spontana kommentarer ----------------
last_title = None


def comment_loop():
    global last_title
    time.sleep(6)
    while True:
        if comments_enabled and not speaking.is_set() and not music_playing() and not guitar_playing():
            title = active_window_title()
            if title and title != last_title:
                last_title = title
                now = time.strftime("%H:%M")
                r = ask(f"[It is {now}. The user just opened the window: \"{title}\". "
                        "Comment in one short sentence.]")
                if r:
                    events.put(r)
        time.sleep(max(10, INTERVAL + random.randint(-10, 20)))


def answer_async(text):
    def run():
        global ui_state
        ui_state = "thinking"
        try:
            if handle_commands(text):
                return
            r = ask(f"[Active window: \"{active_window_title()}\"] {text}", manual=True, raw=text)
            if r:
                events.put(r)
        finally:
            ui_state = "idle"
    threading.Thread(target=run, daemon=True).start()


# ---------------- Mikrofon ----------------
def listen_once(max_wait=7.0, max_len=12.0):
    """Spelar in en mening. Returnerar float32-array eller None."""
    global last_peak
    import sounddevice as sd
    block = int(SAMPLE_RATE * 0.1)
    rolling = collections.deque(maxlen=30)
    last_peak = 0.0
    preroll = collections.deque(maxlen=3)
    frames, started, silence = [], False, 0
    t0 = time.time()
    with sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype="float32", blocksize=block,
                        device=MIC_DEVICE) as stream:
        while True:
            data, _ = stream.read(block)
            chunk = data[:, 0].copy()
            level = float(np.sqrt(np.mean(chunk ** 2)))
            last_peak = max(last_peak, level)
            rolling.append(level)
            loud = level > max(MIC_THRESHOLD, min(rolling) * 3)
            if not started:
                preroll.append(chunk)
                if loud:
                    started = True
                    frames.extend(preroll)
                elif time.time() - t0 > max_wait:
                    return None
            else:
                frames.append(chunk)
                silence = 0 if loud else silence + 1
                if silence >= 8 or len(frames) >= int(max_len * 10):
                    break
    audio = np.concatenate(frames)
    return audio if len(audio) > SAMPLE_RATE * 0.4 else None


def transcribe(audio):
    global whisper_model
    if whisper_model is None:
        events.put(("Loading my ears... (first time it downloads ~150 MB)", False))
        from faster_whisper import WhisperModel
        whisper_model = WhisperModel(WHISPER_MODEL, device="cpu", compute_type="int8")
    segs, _ = whisper_model.transcribe(audio, language=LISTEN_LANG, beam_size=1,
                                       vad_filter=False, condition_on_previous_text=False)
    return " ".join(s.text.strip() for s in segs).strip()


def mic_once(manual=True):
    global always_listen, ui_state
    if not listen_lock.acquire(blocking=False):
        return
    try:
        if not manual:
            while speaking.is_set() or music_playing() or guitar_playing():
                time.sleep(0.2)
        ui_state = "listening"
        if manual:
            events.put(("Listening...", False))
        audio = listen_once(max_wait=7.0 if manual else 3.0)
        if audio is None:
            print(f"[mic] heard nothing. loudest level={last_peak:.4f} "
                  f"(threshold {MIC_THRESHOLD}), device={MIC_DEVICE}")
            if manual:
                events.put(("I can't hear you. Check my microphone.", True))
            return
        ui_state = "thinking"
        text = transcribe(audio)
        if len(text) < 2:
            return
        if handle_commands(text):
            return
        r = ask(f"[Active window: \"{active_window_title()}\"] {text}", manual=True, raw=text)
        if r:
            events.put(r)
    except Exception as e:
        always_listen = False
        traceback.print_exc()
        events.put((f"Mic problem: {e}", False))
    finally:
        ui_state = "idle"
        listen_lock.release()


def listen_loop():
    while True:
        if always_listen and not speaking.is_set() and not music_playing() and not guitar_playing():
            mic_once(manual=False)
        else:
            time.sleep(0.4)


# ---------------- Sprite + gitarr ----------------
def load_sprite():
    paths = ([CHARACTER_IMAGE] if CHARACTER_IMAGE else []) + [os.path.join(here, name) for name in SPRITE_NAMES]
    for p in paths:
        if os.path.isfile(p):
            try:
                im = Image.open(p)
            except Exception:
                continue
            has_alpha = im.mode in ("RGBA", "LA") and im.convert("RGBA").split()[3].getextrema()[0] < 250
            im = im.convert("RGBA")
            if not has_alpha:
                rgb = im.convert("RGB")
                for corner in [(0, 0), (rgb.width - 1, 0), (0, rgb.height - 1), (rgb.width - 1, rgb.height - 1)]:
                    ImageDraw.floodfill(rgb, corner, (255, 0, 255), thresh=70)
                im = rgb.convert("RGBA")
                px = im.load()
                for y in range(im.height):
                    for x in range(im.width):
                        if px[x, y][:3] == (255, 0, 255):
                            px[x, y] = (255, 0, 255, 0)
            return im
    im = Image.new("RGBA", (100, 160), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((20, 10, 80, 70), fill=(150, 60, 220, 255))
    d.rectangle((25, 70, 75, 150), fill=(40, 30, 60, 255))
    return im


def guitar_layer(w, h, frame):
    """Ritar en lila elgitarr över hennes knä. frame 0/1 = lite olika vinkel (stråkning)."""
    S = 3
    W, H = w * S, h * S
    gw, gh = int(W * 0.95), int(H * 0.5)
    g = Image.new("RGBA", (gw, gh), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    cy = gh // 2
    r = gh * 0.34
    bx = gw * 0.26
    body, outline = (88, 36, 150, 255), (235, 170, 255, 255)
    lw = max(2, int(S * 1.5))
    d.ellipse((bx - r * 1.05, cy - r * 0.35, bx + r * 0.75, cy + r * 1.0), fill=body, outline=outline, width=lw)
    d.ellipse((bx - r * 0.75, cy - r * 1.0, bx + r * 0.95, cy + r * 0.25), fill=body, outline=outline, width=lw)
    d.ellipse((bx - r * 0.7, cy - r * 0.45, bx + r * 0.7, cy + r * 0.55), fill=body)
    neck_y0, neck_y1 = cy - gh * 0.07, cy + gh * 0.07
    nut = gw * 0.88
    d.rectangle((bx + r * 0.5, neck_y0, nut, neck_y1), fill=(40, 28, 30, 255), outline=outline, width=1)
    for i in range(1, 8):
        fx = bx + r * 0.5 + (nut - bx - r * 0.5) * i / 8
        d.line((fx, neck_y0, fx, neck_y1), fill=(200, 200, 210, 255), width=1)
    d.rectangle((nut, cy - gh * 0.1, gw * 0.98, cy + gh * 0.1), fill=body, outline=outline, width=lw)
    d.rectangle((bx - r * 0.1, cy - r * 0.3, bx + r * 0.05, cy + r * 0.3), fill=(20, 20, 24, 255))
    d.rectangle((bx + r * 0.25, cy - r * 0.3, bx + r * 0.4, cy + r * 0.3), fill=(20, 20, 24, 255))
    for k in range(3):
        sy = neck_y0 + (neck_y1 - neck_y0) * (k + 0.5) / 3
        d.line((bx - r * 0.3, cy - r * 0.2 + k * r * 0.2, nut, sy), fill=(225, 225, 235, 255), width=1)
    angle = 30 + (4 if frame else -2)
    g = g.rotate(angle, expand=True, resample=Image.BICUBIC)
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    shift = (0, 5 * S) if frame else (0, 0)
    layer.paste(g, (int(W * 0.50 - g.width / 2 + shift[0]), int(H * 0.66 - g.height / 2 + shift[1])), g)
    return layer.resize((w, h), Image.LANCZOS)


def sprite_png_bytes(height=320):
    """Hennes bild som PNG (för mobilsidan)."""
    global sprite_png_cache
    if sprite_png_cache is None:
        sp = load_sprite()
        w = max(10, int(sp.width * height / sp.height))
        buf = io.BytesIO()
        sp.resize((w, height), Image.LANCZOS).save(buf, "PNG")
        sprite_png_cache = buf.getvalue()
    return sprite_png_cache


# ---------------- Mobilsida (webbserver på ditt eget nätverk) ----------------
PHONE_HTML = r"""<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>Uzi</title>
<style>
*{box-sizing:border-box}
body{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#140b20;color:#f2e6ff;
display:flex;flex-direction:column;height:100dvh}
header{display:flex;align-items:center;gap:12px;padding:12px 16px;padding-top:max(12px,env(safe-area-inset-top));
background:#2b1b3d;border-bottom:1px solid #4a2d6b}
header img{height:56px}
header b{font-size:20px}
header span{display:block;font-size:12px;color:#c9a8ff}
header .sp{flex:1}
#warn{display:none;background:#5a2a00;color:#ffd9a8;padding:8px 14px;font-size:13px}
#log{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px}
.m{max-width:82%;padding:9px 13px;border-radius:16px;line-height:1.35;word-wrap:break-word}
.me{align-self:flex-end;background:#6b3fa0}
.uzi{align-self:flex-start;background:#2b1b3d;border:1px solid #4a2d6b}
#bar{display:flex;gap:8px;padding:10px;padding-bottom:max(10px,env(safe-area-inset-bottom));background:#2b1b3d}
#bar input{flex:1;font-size:16px;padding:11px 14px;border-radius:22px;border:1px solid #4a2d6b;background:#140b20;color:#f2e6ff}
button{font-size:16px;border:0;border-radius:22px;padding:10px 15px;background:#6b3fa0;color:#fff}
button:disabled{opacity:.4}
button.rec{background:#d62839}
#callbtn{background:#2a9d5c}
#extra{display:flex;gap:8px;align-items:center;padding:6px 12px;font-size:13px;color:#c9a8ff;background:#1c1030}
#extra button{font-size:13px;padding:6px 12px;background:#3c2358}
#call{position:fixed;inset:0;background:#140b20;display:none;flex-direction:column;align-items:center;justify-content:center;gap:14px;z-index:9}
#call img{height:260px;max-height:40vh}
#call h2{margin:0;font-size:26px}
#ctime{font-size:18px;color:#c9a8ff}
#cstat{font-size:16px;color:#f2e6ff;min-height:24px}
#cbtns{display:flex;gap:18px;margin-top:10px}
#cbtns button{padding:16px 26px;font-size:18px}
#hang{background:#d62839}
#mute.on{background:#e0a100}
</style></head><body>
<header><img id="av" alt=""><div><b>Uzi</b><span id="st">online (on your PC)</span></div><div class="sp"></div>
<button id="callbtn">&#128222; Call</button></header>
<div id="warn">Calls and microphone need HTTPS. You can still chat by typing on the same Wi-Fi.</div>
<div id="log"></div>
<div id="extra"><label><input type="checkbox" id="tts" checked> Read replies aloud</label>
<button id="mus">Music</button><button id="gtr">Guitar</button><button id="stop">Stop</button></div>
<div id="bar"><button id="mic">&#127908;</button><input id="msg" placeholder="Say something..." autocomplete="off"><button id="send">Send</button></div>
<div id="call"><img id="av2" alt=""><h2>Uzi</h2><div id="ctime">00:00</div><div id="cstat">ringing...</div>
<div id="cbtns"><button id="mute">Mute</button><button id="hang">Hang up</button></div></div>
<script>
const tok=new URLSearchParams(location.search).get("t")||"";
const $=id=>document.getElementById(id);
$("av").src="/sprite.png?t="+encodeURIComponent(tok);
$("av2").src="/sprite.png?t="+encodeURIComponent(tok);
const log=$("log"),msg=$("msg");
const SR=window.SpeechRecognition||window.webkitSpeechRecognition,mic=$("mic");
if(!SR||!window.isSecureContext){mic.style.display="none";$("warn").style.display="block"}
function add(c,t){const d=document.createElement("div");d.className="m "+c;d.textContent=t;log.appendChild(d);log.scrollTop=log.scrollHeight;return d}
function speak(t){if(!$("tts").checked||!window.speechSynthesis)return;const u=new SpeechSynthesisUtterance(t);u.lang="en-US";speechSynthesis.speak(u)}
async function post(path,body){const r=await fetch(path+"?t="+encodeURIComponent(tok),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
if(!r.ok)throw new Error("HTTP "+r.status);return r.json()}
async function send(){const t=msg.value.trim();if(!t)return;msg.value="";add("me",t);
if(window.speechSynthesis)speechSynthesis.speak(new SpeechSynthesisUtterance(""));
const w=add("uzi","...");
try{const j=await post("/api/say",{text:t});w.textContent=j.reply;speak(j.reply)}
catch(e){w.textContent="(can't reach the PC - check that Uzi is running and both devices are on the same Wi-Fi)"}}
$("send").onclick=send;
msg.addEventListener("keydown",e=>{if(e.key==="Enter")send()});
async function act(a){try{const j=await post("/api/action",{action:a});add("uzi",j.reply)}catch(e){add("uzi","(no answer)")}}
$("mus").onclick=()=>act("music");$("gtr").onclick=()=>act("guitar");$("stop").onclick=()=>act("stop");

if(SR&&window.isSecureContext){
mic.onclick=()=>{const r=new SR();r.lang=navigator.language||"en-US";mic.classList.add("rec");
r.onresult=e=>{msg.value=e.results[0][0].transcript;send()};
r.onend=()=>mic.classList.remove("rec");r.onerror=()=>mic.classList.remove("rec");r.start()}}

/* ---------- phone call: your voice goes to the PC (Whisper), her voice comes back (Windows voice) ---------- */
const SILENT="data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=";
const TH=0.015;
let inCall=false,busy=false,muted=false,stream=null,ctx=null,proc=null,src=null,chunks=[],pre=[],talking=false,silent=0,speechT=0,t0=0,tick=null,wake=null;
const player=new Audio();player.setAttribute("playsinline","");
function setCall(t){$("cstat").textContent=t}
function merge(list){let n=0;list.forEach(a=>n+=a.length);const o=new Float32Array(n);let p=0;list.forEach(a=>{o.set(a,p);p+=a.length});return o}
function down(buf,from,to){if(from===to)return buf;const r=from/to,n=Math.floor(buf.length/r),o=new Float32Array(n);
for(let i=0;i<n;i++){const a=Math.floor(i*r),b=Math.min(buf.length,Math.floor((i+1)*r));let s=0;for(let j=a;j<b;j++)s+=buf[j];o[i]=s/Math.max(1,b-a)}return o}
function toPCM(f){const o=new Int16Array(f.length);for(let i=0;i<f.length;i++){const x=Math.max(-1,Math.min(1,f[i]));o[i]=x<0?x*32768:x*32767}return o}
function play(b64){return new Promise(res=>{if(!b64)return res();setCall("Uzi is talking...");player.src="data:audio/wav;base64,"+b64;
player.onended=()=>setTimeout(res,350);player.onerror=()=>res();player.play().catch(()=>res())})}
function ring(){return new Promise(res=>{const g=ctx.createGain();g.gain.value=0;g.connect(ctx.destination);
const a=ctx.createOscillator(),b=ctx.createOscillator();a.frequency.value=440;b.frequency.value=480;a.connect(g);b.connect(g);a.start();b.start();
const n=ctx.currentTime;g.gain.setValueAtTime(0.12,n);g.gain.setValueAtTime(0,n+1.0);g.gain.setValueAtTime(0.12,n+1.6);g.gain.setValueAtTime(0,n+2.6);
a.stop(n+2.7);b.stop(n+2.7);setTimeout(res,2800)})}
function onChunk(e){
if(!inCall||busy||muted)return;
const d=e.inputBuffer.getChannelData(0);let s=0;for(let i=0;i<d.length;i++)s+=d[i]*d[i];
const rms=Math.sqrt(s/d.length),dur=d.length/ctx.sampleRate,c=new Float32Array(d);
if(rms>TH){if(!talking){talking=true;chunks=pre.slice();speechT=0}silent=0;chunks.push(c);speechT+=dur}
else if(talking){chunks.push(c);silent+=dur;speechT+=dur;if(silent>0.9)finish()}
else{pre.push(c);if(pre.length>3)pre.shift()}
if(talking&&speechT>15)finish()}
async function finish(){
talking=false;busy=true;const all=merge(chunks);chunks=[];silent=0;
const ok=all.length>ctx.sampleRate*0.5;speechT=0;
if(!ok){busy=false;return}
setCall("thinking...");
try{const pcm=toPCM(down(all,ctx.sampleRate,16000));
const r=await fetch("/api/voice?t="+encodeURIComponent(tok),{method:"POST",headers:{"Content-Type":"application/octet-stream"},body:pcm.buffer});
if(!r.ok)throw new Error("HTTP "+r.status);const j=await r.json();
if(j.heard)add("me",j.heard);if(j.reply){add("uzi",j.reply);await play(j.wav)}}
catch(e){add("uzi","(connection hiccup)")}
busy=false;if(inCall)setCall("listening...")}
async function startCall(){
if(inCall)return;
try{player.src=SILENT;await player.play().catch(()=>{});
stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}})}
catch(e){alert("I can't use the microphone ("+e.message+"). Phone calls need HTTPS and microphone permission.");return}
ctx=new (window.AudioContext||window.webkitAudioContext)();await ctx.resume();
src=ctx.createMediaStreamSource(stream);proc=ctx.createScriptProcessor(4096,1,1);proc.onaudioprocess=onChunk;
src.connect(proc);proc.connect(ctx.destination);
inCall=true;busy=true;muted=false;$("mute").classList.remove("on");chunks=[];pre=[];talking=false;
$("call").style.display="flex";t0=Date.now();
tick=setInterval(()=>{const s=Math.floor((Date.now()-t0)/1000);$("ctime").textContent=String(Math.floor(s/60)).padStart(2,"0")+":"+String(s%60).padStart(2,"0")},500);
try{wake=await navigator.wakeLock.request("screen")}catch(e){}
setCall("ringing...");await ring();
try{const j=await post("/api/call_start",{});add("uzi",j.reply);await play(j.wav)}catch(e){add("uzi","(no answer)")}
busy=false;if(inCall)setCall("listening...")}
function hangup(){
inCall=false;busy=false;
try{proc.disconnect();src.disconnect()}catch(e){}
try{stream.getTracks().forEach(t=>t.stop())}catch(e){}
try{ctx.close()}catch(e){}
player.pause();clearInterval(tick);try{wake&&wake.release()}catch(e){}
$("call").style.display="none"}
$("callbtn").onclick=startCall;$("hang").onclick=hangup;
$("mute").onclick=()=>{muted=!muted;$("mute").classList.toggle("on",muted);$("mute").textContent=muted?"Unmute":"Mute";if(muted)setCall("muted")}
</script></body></html>
"""


def get_token():
    if not saved.get("phone_token"):
        saved["phone_token"] = secrets.token_urlsafe(9)
        save_settings()
    return saved["phone_token"]


def lan_interface():
    candidates = []
    try:
        import psutil
        stats = psutil.net_if_stats()
        for name, addresses in psutil.net_if_addrs().items():
            lowered = name.lower()
            if (not stats.get(name) or not stats[name].isup
                    or any(x in lowered for x in ("loopback", "tailscale", "vpn", "virtual", "wireguard",
                                                   "docker", "hyper-v", "vmware", "bridge", "wsl"))):
                continue
            for address in addresses:
                if address.family != socket.AF_INET:
                    continue
                ip = ipaddress.ip_address(address.address)
                if ip.is_unspecified or ip.is_loopback or ip.is_link_local or ip.is_multicast:
                    continue
                if not address.netmask:
                    continue
                network = ipaddress.ip_interface(f"{ip}/{address.netmask}").network
                if network.prefixlen == 32:
                    continue
                if any(x in lowered for x in ("wi-fi", "wifi", "wireless")):
                    priority = 0
                elif "ethernet" in lowered:
                    priority = 1
                else:
                    priority = 2
                candidates.append((priority, address.address, network))
    except Exception:
        return None
    return min(candidates, key=lambda item: item[0])[1:] if candidates else None


def lan_ip():
    interface = lan_interface()
    return interface[0] if interface else "127.0.0.1"


def phone_url():
    host = phone_server.server_address[0] if phone_server is not None else lan_ip()
    return f"http://{host}:{PHONE_PORT}/?t={get_token()}"


def phone_say(text):
    out = []
    if handle_commands(text, phone=True, out=out):
        return " ".join(out) or "Okay. Done. Whatever."
    r = ask(f"[The user is texting you from their phone] {text}", manual=True, raw=text)
    return r[0] if r else "..."


def phone_action(action):
    if action == "music":
        threading.Thread(target=play_music, kwargs={"manual": True}, daemon=True).start()
        return "Fine. Music. On your PC."
    if action == "guitar":
        threading.Thread(target=play_guitar, kwargs={"manual": True}, daemon=True).start()
        return "Guitar. On your PC. Hope nobody's sleeping."
    stop_music()
    stop_guitar()
    return "Silence. My favorite."


def tts_wav(text):
    """Hennes röst som WAV (Windows talsyntes) så att mobilen kan spela upp den."""
    path = os.path.join(here, f".uzi_tts_{secrets.token_hex(4)}.wav")
    try:
        subprocess.run(timeout=60, **ps_command(PS_SPEAK_WAV, {
            "UZI_TEXT": text, "UZI_VOICE": VOICE_NAME, "UZI_RATE": str(int(VOICE_RATE)), "UZI_OUT": path}))
        with open(path, "rb") as f:
            return f.read()
    except Exception as e:
        print("[phone] tts error:", e)
        return b""
    finally:
        try:
            os.remove(path)
        except Exception:
            pass


def phone_voice(pcm):
    """Samtal: 16 kHz mono 16-bit PCM från mobilen -> Whisper -> Uzi -> röst som WAV."""
    empty = {"heard": "", "reply": "", "wav": ""}
    audio = np.frombuffer(pcm[: len(pcm) // 2 * 2], dtype=np.int16).astype(np.float32) / 32768.0
    if len(audio) < SAMPLE_RATE * 0.4:
        return empty
    with stt_lock:
        text = transcribe(audio)
    if len(text) < 2:
        return empty
    reply = phone_say(text)
    wav = tts_wav(reply) if reply else b""
    return {"heard": text, "reply": reply, "wav": base64.b64encode(wav).decode() if wav else ""}


def phone_call_start():
    r = ask("[The user is calling you on the phone and you just picked up. Answer the call in character, "
            "one short sentence.]")
    reply = r[0] if r and r[1] else "...what. You called me. Say something."
    wav = tts_wav(reply)
    return {"reply": reply, "wav": base64.b64encode(wav).decode() if wav else ""}


def phone_screen_snapshot():
    if not PHONE_SCREEN_VIEW:
        return None
    try:
        image = ImageGrab.grab(all_screens=True)
        image.thumbnail((1440, 900), Image.LANCZOS)
        output = io.BytesIO()
        image.convert("RGB").save(output, "JPEG", quality=72, optimize=True)
        return output.getvalue()
    except Exception as e:
        print("[phone] screen capture error:", e)
        return None


def phone_activity():
    title = active_window_title() or "Desktop"
    if ui_state == "listening":
        activity = "Listening to you"
    elif ui_state == "thinking":
        activity = "Thinking"
    elif speaking.is_set():
        activity = "Speaking"
    elif music_playing():
        activity = f"Playing music: {music_title or 'Music'}"
    elif guitar_playing():
        activity = "Playing guitar"
    else:
        activity = "Hanging out on the PC"
    return {"window": title[:160], "activity": activity}


def phone_client_is_on_lan(address):
    if phone_lan_network is None:
        return False
    try:
        return ipaddress.ip_address(address) in phone_lan_network
    except ValueError:
        return False


class PhoneHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _authed(self):
        if not phone_client_is_on_lan(self.client_address[0]):
            time.sleep(0.5)
            return False
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        tok = self.headers.get("X-Token") or (q.get("t") or [""])[0]
        if not tok:
            try:
                c = http.cookies.SimpleCookie(self.headers.get("Cookie", ""))
                tok = c["uzi_t"].value if "uzi_t" in c else ""
            except Exception:
                tok = ""
        ok = hmac.compare_digest(tok.encode(), get_token().encode())
        if not ok:
            time.sleep(0.5)                                    # gör gissning av koden långsam
        return ok

    def _send(self, code, body, ctype="application/json", headers=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith("text") else ""))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _forbidden(self):
        self._send(403, "Forbidden.\n\nThis link is missing Uzi's secret code. Open the FULL link from Uzi's "
                        "Phone tab (it ends in ?t=...), or scan the QR code again.", "text/plain")

    def do_GET(self):
        if not self._authed():
            return self._forbidden()
        path = urllib.parse.urlparse(self.path).path
        if path == "/":
            self._send(200, PHONE_HTML, "text/html", {
                "Set-Cookie": f"uzi_t={get_token()}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Strict"})
        elif path == "/sprite.png":
            self._send(200, sprite_png_bytes(), "image/png")
        elif path == "/api/activity":
            if not PHONE_SCREEN_VIEW:
                return self._send(403, json.dumps({"error": "Screen viewing is off on the PC."}))
            return self._send(200, json.dumps(phone_activity()))
        elif path == "/api/screen":
            if not PHONE_SCREEN_VIEW:
                return self._send(403, "Screen viewing is off on the PC.", "text/plain")
            image = phone_screen_snapshot()
            if image is None:
                return self._send(503, "Screen capture is unavailable.", "text/plain")
            return self._send(200, image, "image/jpeg")
        else:
            self._send(404, "Not found", "text/plain")

    def do_POST(self):
        if not self._authed():
            return self._forbidden()
        path = urllib.parse.urlparse(self.path).path
        try:
            n = int(self.headers.get("Content-Length", 0))
            if n > (1_500_000 if path == "/api/voice" else 4096):
                return self._send(413, "Too large", "text/plain")
            raw = self.rfile.read(n) if n else b""
            data = {} if path == "/api/voice" else json.loads(raw or b"{}")
        except Exception:
            return self._send(400, "Bad request", "text/plain")
        try:
            if path == "/api/say":
                text = str(data.get("text", ""))[:500].strip()
                if not text:
                    return self._send(400, json.dumps({"reply": "..."}))
                return self._send(200, json.dumps({"reply": phone_say(text)}))
            if path == "/api/action":
                return self._send(200, json.dumps({"reply": phone_action(str(data.get("action", "")))}))
            if path == "/api/voice":
                return self._send(200, json.dumps(phone_voice(raw)))
            if path == "/api/call_start":
                return self._send(200, json.dumps(phone_call_start()))
            self._send(404, "Not found", "text/plain")
        except Exception:
            traceback.print_exc()
            self._send(500, json.dumps({"reply": "Something broke on my side."}))


def start_phone():
    global phone_server, phone_error, phone_lan_network
    if phone_server is not None:
        return True
    interface = lan_interface()
    if not interface:
        phone_error = "No active Wi-Fi/Ethernet IPv4 interface found. Connect both devices to the same network, then retry."
        return False
    host, network = interface
    try:
        srv = http.server.ThreadingHTTPServer((host, int(PHONE_PORT)), PhoneHandler)
    except OSError as e:
        phone_error = f"Could not start the phone page: {e}"
        return False
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    phone_lan_network = network
    phone_server, phone_error = srv, ""
    return True


def stop_phone():
    global phone_server, phone_lan_network
    srv, phone_server = phone_server, None
    phone_lan_network = None
    if srv is not None:
        try:
            srv.shutdown()
            srv.server_close()
        except Exception:
            pass


# ---------------- Soffan ----------------
def request_sit():
    globals()["sit_request"] = "sit"


def request_stand():
    globals()["sit_request"] = "stand"


COUCH_PALETTES = {
    "Plum": ((96, 52, 140, 255), (70, 36, 108, 255), (122, 74, 170, 255), (230, 190, 255, 255),
             (40, 24, 60, 255)),
    "Rose": ((177, 69, 105, 255), (119, 43, 76, 255), (224, 120, 151, 255), (255, 204, 218, 255),
             (70, 32, 48, 255)),
    "Teal": ((43, 130, 125, 255), (28, 83, 82, 255), (86, 185, 171, 255), (190, 245, 229, 255),
             (23, 57, 57, 255)),
    "Midnight": ((73, 78, 105, 255), (43, 46, 67, 255), (115, 124, 156, 255), (207, 220, 244, 255),
                 (25, 27, 40, 255)),
}


def draw_couch(W, H, h):
    """Ritar en lila soffa (W x H px). h = Uzis höjd, alla mått räknas som andel av den."""
    S = 2
    im = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    u, bottom, WS = h * S, H * S, W * S
    fabric, dark, light, edge, legs = COUCH_PALETTES.get(COUCH_STYLE, COUCH_PALETTES["Plum"])
    lw = max(2, int(u * 0.012))
    for lx in (0.16, 0.84):
        d.rectangle((WS * lx - u * 0.03, bottom - u * 0.09, WS * lx + u * 0.03, bottom), fill=legs)
    d.rounded_rectangle((WS * 0.06, bottom - u * 0.80, WS * 0.94, bottom - u * 0.30), radius=u * 0.10,
                        fill=dark, outline=edge, width=lw)
    d.rounded_rectangle((WS * 0.04, bottom - u * 0.36, WS * 0.96, bottom - u * 0.10), radius=u * 0.07,
                        fill=fabric, outline=edge, width=lw)
    for a, b in ((0.10, 0.49), (0.51, 0.90)):
        d.rounded_rectangle((WS * a, bottom - u * 0.40, WS * b, bottom - u * 0.24), radius=u * 0.06,
                            fill=light, outline=edge, width=lw)
    for a, b in ((0.0, 0.10), (0.90, 1.0)):
        d.rounded_rectangle((WS * a, bottom - u * 0.52, WS * b, bottom - u * 0.10), radius=u * 0.06,
                            fill=fabric, outline=edge, width=lw)
    return im.resize((W, H), Image.LANCZOS)


class Couch:
    """Soffan: ett eget fönster du kan dra runt. När hon sitter visas hon i soffan i sitt eget fönster."""

    def __init__(self, app):
        self.app = app
        t = self.win = tk.Toplevel(app.root)
        t.overrideredirect(True)
        t.attributes("-topmost", True)
        t.attributes("-transparentcolor", KEY)
        t.config(bg=KEY)
        self.label = tk.Label(t, image=app.imgs["C"], bg=KEY, bd=0)
        self.label.pack()
        m = app.mons[0]
        self.x = saved.get("couch_x", m[0] + (m[2] - m[0]) // 4)
        self.y = saved.get("couch_y", m[3] - app.ch)
        self.moved = False
        self.dragging = False
        self.airborne = False
        self.vy = 0
        self.support_kind = None
        self.support_hwnd = None
        self.fall_start_y = self.y
        self.label.bind("<ButtonPress-1>", self.on_press)
        self.label.bind("<B1-Motion>", self.on_motion)
        self.label.bind("<ButtonRelease-1>", self.on_release)
        menu = tk.Menu(t, tearoff=0)
        menu.add_command(label="Make her sit", command=request_sit)
        menu.add_command(label="Make her stand up", command=request_stand)
        self.label.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))
        self.snap()
        self.find_support()
        self.apply()

    @property
    def enabled(self):
        return bool(COUCH_ENABLED)

    def apply(self):
        """Visar soffan som eget fönster - utom när hon sitter i den (då visas hon + soffan i hennes fönster)."""
        if self.enabled and not self.app.sitting:
            self.win.deiconify()
            self.win.geometry(f"{self.app.cw}x{self.app.ch}+{int(self.x)}+{int(self.y)}")
        else:
            self.win.withdraw()

    def refresh(self):
        self.label.config(image=self.app.imgs["C"])
        self.snap()
        self.support_kind = None
        self.support_hwnd = None
        if not self.find_support():
            self.airborne = True
            self.fall_start_y = self.y
            self.vy = 0
        self.apply()

    def snap(self):
        app = self.app
        m = app.monitor_at(self.x + app.cw // 2, self.y + app.ch - 2)
        self.x = max(m[0], min(self.x, m[2] - app.cw))
        self.y = max(m[1], min(self.y, m[3] - app.ch))

    def platform_y(self):
        return self.y + int(self.app.ch * 0.6)

    def find_support(self, tolerance=24):
        app = self.app
        bottom = self.y + app.ch
        candidates = []
        for hwnd, rect in app.window_surfaces:
            left, top, right, _ = rect
            if self.x + app.cw > left + 4 and self.x < right - 4 and abs(bottom - top) <= tolerance:
                candidates.append((abs(bottom - top), top, hwnd))
        if candidates:
            _, top, self.support_hwnd = min(candidates)
            self.support_kind = "window"
            self.y = top - app.ch
            self.airborne = False
            self.vy = 0
            return True
        monitor = app.monitor_at(self.x + app.cw // 2, bottom - 2)
        if abs(bottom - monitor[3]) <= tolerance:
            self.support_kind = "floor"
            self.support_hwnd = None
            self.y = monitor[3] - app.ch
            self.airborne = False
            self.vy = 0
            return True
        self.support_kind = None
        self.support_hwnd = None
        return False

    def physics_tick(self):
        app = self.app
        if not self.enabled or app.sitting or self.dragging:
            return
        if self.support_kind == "window":
            rect = next((rect for hwnd, rect in app.window_surfaces if hwnd == self.support_hwnd), None)
            if rect and self.x + app.cw > rect[0] + 4 and self.x < rect[2] - 4:
                self.y = rect[1] - app.ch
            else:
                self.support_kind = None
                self.support_hwnd = None
                self.airborne = True
                self.fall_start_y = self.y
                self.vy = 0
        elif self.support_kind == "floor":
            monitor = app.monitor_at(self.x + app.cw // 2, self.y + app.ch - 2)
            floor_y = monitor[3] - app.ch
            if self.y < floor_y:
                self.support_kind = None
                self.airborne = True
                self.fall_start_y = self.y
                self.vy = 0
            else:
                self.y = floor_y
        if self.support_kind is None and not self.airborne and not self.find_support(4):
            self.airborne = True
            self.fall_start_y = self.y
            self.vy = 0
        if self.airborne:
            old_bottom = self.y + app.ch
            self.vy = min(self.vy + 3.2, 36)
            self.y += self.vy
            new_bottom = self.y + app.ch
            landed = []
            for hwnd, rect in app.window_surfaces:
                left, top, right, _ = rect
                if old_bottom <= top <= new_bottom and self.x + app.cw > left + 4 and self.x < right - 4:
                    landed.append((top, hwnd))
            if landed:
                top, self.support_hwnd = min(landed)
                self.y = top - app.ch
                self.support_kind = "window"
                self.airborne = False
            else:
                monitor = app.monitor_at(self.x + app.cw // 2, new_bottom - 2)
                if new_bottom >= monitor[3]:
                    self.y = monitor[3] - app.ch
                    self.support_kind = "floor"
                    self.support_hwnd = None
                    self.airborne = False
            if not self.airborne and self.y - self.fall_start_y > 120:
                app.react("land")
        if self.enabled and not app.sitting:
            self.win.geometry(f"{app.cw}x{app.ch}+{int(self.x)}+{int(self.y)}")

    def on_press(self, e):
        self.px, self.py, self.sx, self.sy = e.x_root, e.y_root, self.x, self.y
        self.moved = False

    def on_motion(self, e):
        dx, dy = e.x_root - self.px, e.y_root - self.py
        if not self.moved and abs(dx) + abs(dy) < 6:
            return
        if not self.dragging:
            self.dragging = True
            self.airborne = False
            self.support_kind = None
            self.support_hwnd = None
            if self.app.platform_kind == "couch":
                self.app.platform_kind = None
                self.app.airborne = True
                self.app.drop_y = self.app.y
                self.app.vy = 0
        self.moved = True
        self.x, self.y = self.sx + dx, self.sy + dy
        lo_x, hi_x = min(m[0] for m in self.app.mons), max(m[2] for m in self.app.mons)
        lo_y, hi_y = min(m[1] for m in self.app.mons), max(m[3] for m in self.app.mons)
        self.x = max(lo_x, min(self.x, hi_x - self.app.cw))
        self.y = max(lo_y, min(self.y, hi_y - self.app.ch))
        self.win.geometry(f"+{int(self.x)}+{int(self.y)}")

    def on_release(self, e):
        if self.moved:
            self.dragging = False
            if not self.find_support():
                self.airborne = True
                self.fall_start_y = self.y
                self.vy = 0
            self.apply()
            saved["couch_x"], saved["couch_y"] = self.x, self.y
            save_settings()


# ---------------- Prata-knappen (flyttbar) ----------------
class TalkButton:
    SIZE = 64
    COLORS = {"idle": "#6b3fa0", "listening": "#d62839", "thinking": "#e0a100", "speaking": "#2a9d5c"}

    def __init__(self, app):
        self.app = app
        S = self.SIZE
        t = self.win = tk.Toplevel(app.root)
        t.overrideredirect(True)
        t.attributes("-topmost", True)
        t.attributes("-transparentcolor", KEY)
        t.config(bg=KEY)
        self.cv = tk.Canvas(t, width=S, height=S, bg=KEY, highlightthickness=0)
        self.cv.pack()
        self.oval = self.cv.create_oval(4, 4, S - 4, S - 4, fill=self.COLORS["idle"],
                                        outline="#d9c7ff", width=3)
        self.cv.create_text(S // 2, S // 2, text="\U0001F3A4", font=("Segoe UI Emoji", 20), fill="white")
        m = app.mons[0]
        lo_x, hi_x = min(a[0] for a in app.mons), max(a[2] for a in app.mons)
        lo_y, hi_y = min(a[1] for a in app.mons), max(a[3] for a in app.mons)
        self.x = max(lo_x, min(saved.get("btn_x", m[2] - S - 40), hi_x - S))
        self.y = max(lo_y, min(saved.get("btn_y", m[3] - S - 140), hi_y - S))
        t.geometry(f"{S}x{S}+{self.x}+{self.y}")
        self.state = "idle"
        self.moved = False
        self.cv.bind("<ButtonPress-1>", self.on_press)
        self.cv.bind("<B1-Motion>", self.on_motion)
        self.cv.bind("<ButtonRelease-1>", self.on_release)
        menu = tk.Menu(t, tearoff=0)
        menu.add_command(label="Control panel", command=app.panel_show)
        menu.add_command(label="Stop music / guitar", command=lambda: (stop_music(), stop_guitar()))
        menu.add_command(label="TURN OFF PC control", command=app.panic_off)
        menu.add_command(label="Quit", command=app.quit)
        self.cv.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))

    def on_press(self, e):
        self.px, self.py, self.sx, self.sy = e.x_root, e.y_root, self.x, self.y
        self.moved = False

    def on_motion(self, e):
        dx, dy = e.x_root - self.px, e.y_root - self.py
        if not self.moved and abs(dx) + abs(dy) < 6:
            return
        self.moved = True
        self.x, self.y = self.sx + dx, self.sy + dy
        self.win.geometry(f"+{self.x}+{self.y}")

    def on_release(self, e):
        if self.moved:
            saved["btn_x"], saved["btn_y"] = self.x, self.y
            save_settings()
        else:
            self.app.mic()

    def set_state(self, state):
        if state != self.state:
            self.state = state
            self.cv.itemconfig(self.oval, fill=self.COLORS[state])

    def set_visible(self, v):
        (self.win.deiconify if v else self.win.withdraw)()


# ---------------- Kontrollpanel ----------------
def input_devices():
    out = [(None, "Windows default microphone")]
    try:
        import sounddevice as sd
        for i, d in enumerate(sd.query_devices()):
            if d["max_input_channels"] > 0:
                out.append((i, f"[{i}] {d['name']}"))
    except Exception:
        pass
    return out


def setg(name):
    """Returnerar en funktion som sätter en global variabel (för skjutreglage)."""
    return lambda v: globals().__setitem__(name, v)


class Panel:
    def __init__(self, app):
        self.app = app
        self.synced = []
        w = self.win = tk.Toplevel(app.root)
        w.title("Uzi control panel")
        w.geometry("+80+80")
        w.resizable(False, False)
        w.protocol("WM_DELETE_WINDOW", w.withdraw)
        style = ttk.Style(w)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        bg, surface, input_bg = "#211822", "#302330", "#18151d"
        pink, coral, teal, text, muted = "#f28ba8", "#d76b82", "#67cfc2", "#f4eaf1", "#cbbac7"
        w.configure(bg=bg)
        style.configure("TFrame", background=bg)
        style.configure("TLabel", background=bg, foreground=text)
        style.configure("TButton", background="#493447", foreground=text, bordercolor="#69495f",
                        lightcolor="#493447", darkcolor="#493447", focuscolor=pink, padding=(9, 6))
        style.map("TButton", background=[("disabled", "#332833"), ("pressed", coral), ("active", "#684255")],
                  foreground=[("disabled", "#907d88"), ("active", "#ffffff")])
        style.configure("TCheckbutton", background=bg, foreground=text, padding=(3, 4))
        style.map("TCheckbutton", background=[("active", bg)], foreground=[("active", pink)],
                  indicatorcolor=[("selected", pink), ("!selected", "#766171")])
        style.configure("TNotebook", background=bg, borderwidth=0, tabmargins=(0, 0, 0, 0))
        style.configure("TNotebook.Tab", background="#382938", foreground=muted, padding=(10, 7), borderwidth=0)
        style.map("TNotebook.Tab", background=[("selected", surface), ("active", "#50384a")],
                  foreground=[("selected", pink), ("active", text)])
        style.configure("TEntry", fieldbackground=input_bg, foreground=text, insertcolor=text,
                        bordercolor="#69495f", padding=5)
        style.configure("TCombobox", fieldbackground=input_bg, background="#493447", foreground=text,
                        arrowcolor=pink, bordercolor="#69495f", padding=4)
        style.map("TCombobox", fieldbackground=[("readonly", input_bg)], foreground=[("readonly", text)])
        style.configure("TScale", background=bg, troughcolor="#583b50")
        style.configure("TSpinbox", fieldbackground=input_bg, background="#493447", foreground=text,
                        arrowcolor=pink, bordercolor="#69495f")
        style.configure("TLabelframe", background=bg, bordercolor="#69495f")
        style.configure("TLabelframe.Label", background=bg, foreground=pink,
                        font=("Segoe UI", 9, "bold"))
        style.configure("Uzi.Header.TFrame", background=surface)
        style.configure("Uzi.Title.TLabel", background=surface, foreground=pink,
                        font=("Segoe UI", 20, "bold"))
        style.configure("Uzi.Eyebrow.TLabel", background=surface, foreground=teal,
                        font=("Segoe UI", 8, "bold"))
        style.configure("Uzi.Status.TLabel", background=bg, foreground=teal)

        main = ttk.Frame(w, padding=12)
        main.pack(fill="both")
        brand = ttk.Frame(main, style="Uzi.Header.TFrame", padding=(10, 7))
        brand.pack(fill="x")
        ttk.Label(brand, text="Uzi", style="Uzi.Title.TLabel").pack(side="left")
        ttk.Label(brand, text="CONTROL DECK", style="Uzi.Eyebrow.TLabel").pack(side="left", padx=(10, 0), pady=(8, 0))

        row = ttk.Frame(main)
        row.pack(fill="x", pady=(6, 2))
        ttk.Button(row, text="Talk (mic)", command=app.mic).pack(side="left", padx=2)
        ttk.Button(row, text="Type...", command=app.type_to).pack(side="left", padx=2)
        ttk.Button(row, text="Test voice", command=self.test_voice).pack(side="left", padx=2)
        ttk.Button(row, text="Test brain", command=self.test_brain).pack(side="left", padx=2)

        nb = ttk.Notebook(main)
        nb.pack(fill="both", pady=8)
        tabs = {}
        for name in ("General", "Character", "Voice & mic", "Music", "PC control", "Camera", "Phone", "Memory"):
            tabs[name] = ttk.Frame(nb, padding=8)
            nb.add(tabs[name], text=name)

        # --- Character ---
        t = tabs["Character"]
        profile = ttk.LabelFrame(t, text="Character profile", padding=8)
        profile.pack(fill="x", pady=(0, 8))
        preset_row = ttk.Frame(profile)
        preset_row.pack(fill="x", pady=(0, 5))
        ttk.Label(preset_row, text="Preset").pack(side="left", padx=(0, 8))
        self.character_preset_var = tk.StringVar(value=CHARACTER_PRESET)
        self.character_preset_combo = ttk.Combobox(
            preset_row, textvariable=self.character_preset_var, state="readonly",
            values=tuple(PERSONALITY_PRESETS), width=18)
        self.character_preset_combo.pack(side="left")
        ttk.Button(preset_row, text="Load preset", command=self.load_character_preset).pack(side="left", padx=6)
        ttk.Label(profile, text="Portrait image").pack(anchor="w")
        image_row = ttk.Frame(profile)
        image_row.pack(fill="x", pady=(2, 6))
        self.character_image_var = tk.StringVar(value=CHARACTER_IMAGE)
        ttk.Entry(image_row, textvariable=self.character_image_var, width=36).pack(side="left", fill="x", expand=True)
        ttk.Button(image_row, text="Browse", command=self.browse_character_image).pack(side="left", padx=(5, 0))
        ttk.Button(image_row, text="Default", command=lambda: self.character_image_var.set("")).pack(side="left", padx=(4, 0))
        ttk.Label(profile, text="Personality").pack(anchor="w")
        self.personality_text = tk.Text(profile, height=6, wrap="word", bg="#18151d", fg="#f4eaf1",
                                        insertbackground="#f28ba8", selectbackground="#684255",
                                        relief="flat", padx=7, pady=6, highlightthickness=1,
                                        highlightbackground="#69495f", highlightcolor="#f28ba8")
        initial_personality = PERSONALITY_TEXT or PERSONALITY_PRESETS.get(CHARACTER_PRESET, "")
        if initial_personality:
            self.personality_text.insert("1.0", initial_personality)
        self.personality_text.pack(fill="both", expand=True, pady=(2, 6))
        ttk.Button(profile, text="Apply character", command=self.apply_character).pack(anchor="e")

        couch_profile = ttk.LabelFrame(t, text="Couch appearance", padding=8)
        couch_profile.pack(fill="x")
        style_row = ttk.Frame(couch_profile)
        style_row.pack(fill="x", pady=(0, 5))
        ttk.Label(style_row, text="Built-in style").pack(side="left", padx=(0, 8))
        self.couch_style_var = tk.StringVar(value=COUCH_STYLE)
        ttk.Combobox(style_row, textvariable=self.couch_style_var, state="readonly",
                     values=tuple(COUCH_PALETTES), width=18).pack(side="left")
        ttk.Label(couch_profile, text="Custom couch image").pack(anchor="w")
        couch_image_row = ttk.Frame(couch_profile)
        couch_image_row.pack(fill="x", pady=(2, 6))
        self.couch_image_var = tk.StringVar(value=COUCH_IMAGE)
        ttk.Entry(couch_image_row, textvariable=self.couch_image_var, width=36).pack(side="left", fill="x", expand=True)
        ttk.Button(couch_image_row, text="Browse", command=self.browse_couch_image).pack(side="left", padx=(5, 0))
        ttk.Button(couch_image_row, text="Default", command=lambda: self.couch_image_var.set("")).pack(side="left", padx=(4, 0))
        ttk.Button(couch_profile, text="Apply couch", command=self.apply_couch).pack(anchor="e")

        # --- General ---
        t = tabs["General"]
        self.v_show = tk.BooleanVar(value=True)
        self.v_button = tk.BooleanVar(value=True)
        self.v_walk = tk.BooleanVar(value=app.walking)
        ttk.Checkbutton(t, text="Show Uzi", variable=self.v_show,
                        command=lambda: app.set_visible(self.v_show.get())).pack(anchor="w")
        ttk.Checkbutton(t, text="Show talk button", variable=self.v_button,
                        command=lambda: app.button.set_visible(self.v_button.get())).pack(anchor="w")
        ttk.Checkbutton(t, text="Walk around", variable=self.v_walk,
                        command=lambda: setattr(app, "walking", self.v_walk.get())).pack(anchor="w")
        self.check(t, "Climb active windows automatically", "CLIMB_WINDOWS")
        ttk.Button(t, text="Climb active window", command=app.climb_active_window).pack(anchor="w", pady=2)
        self.check(t, "Show her couch (she sits on it sometimes; drag it anywhere)", "COUCH_ENABLED",
                   after=app.couch_toggle)
        crow2 = ttk.Frame(t)
        crow2.pack(fill="x", pady=2)
        ttk.Button(crow2, text="Make her sit", command=request_sit).pack(side="left", padx=2)
        ttk.Button(crow2, text="Make her stand up", command=request_stand).pack(side="left", padx=2)
        self.check(t, "Comment on what I'm doing", "comments_enabled", sync=True)
        self.check(t, "She misses me when I'm away", "MISS_ENABLED")
        self.slider(t, "Comment every (s)", 15, 300, INTERVAL, setg("INTERVAL"))
        self.slider(t, "Missed after (min)", 5, 60, MISS_AFTER, setg("MISS_AFTER"))
        self.slider(t, "Catchphrase %", 0, 40, CATCHPHRASE_CHANCE, setg("CATCHPHRASE_CHANCE"))
        self.slider(t, "Uzi size", 80, 320, SPRITE_HEIGHT, app.schedule_resize)

        # --- Voice & mic ---
        t = tabs["Voice & mic"]
        self.check(t, "Speak out loud", "SPEAK", after=lambda: SPEAK or stop_speaking())
        self.check(t, "Listen all the time", "always_listen", sync=True)
        self.slider(t, "Voice speed", -4, 6, VOICE_RATE, setg("VOICE_RATE"))
        ttk.Label(t, text="Microphone:").pack(anchor="w", pady=(8, 0))
        self.devs = input_devices()
        self.combo = ttk.Combobox(t, state="readonly", width=46, values=[n for _, n in self.devs])
        self.combo.current(next((k for k, (d, _) in enumerate(self.devs) if d == MIC_DEVICE), 0))
        self.combo.bind("<<ComboboxSelected>>", self.on_mic_pick)
        self.combo.pack(fill="x")
        ttk.Button(t, text="Test microphone (3 s)", command=self.test_mic).pack(anchor="w", pady=(6, 0))

        # --- Music + guitar ---
        t = tabs["Music"]
        self.check(t, "Uzi may put on music sometimes (to annoy me)", "MUSIC_ENABLED")
        self.slider(t, "Music every ~(min)", 2, 60, MUSIC_EVERY, setg("MUSIC_EVERY"))
        self.slider(t, "Music volume", 5, 100, MUSIC_VOL, setg("MUSIC_VOL"))
        self.check(t, "Uzi may play her guitar / talk about it", "GUITAR_ENABLED")
        self.slider(t, "Guitar every ~(min)", 3, 60, GUITAR_EVERY, setg("GUITAR_EVERY"))
        self.slider(t, "Guitar volume", 10, 100, GUITAR_VOL, setg("GUITAR_VOL"))
        mrow = ttk.Frame(t)
        mrow.pack(fill="x", pady=6)
        ttk.Button(mrow, text="Play music", command=lambda: threading.Thread(
            target=play_music, kwargs={"manual": True}, daemon=True).start()).pack(side="left", padx=2)
        ttk.Button(mrow, text="Play guitar", command=lambda: threading.Thread(
            target=play_guitar, kwargs={"manual": True}, daemon=True).start()).pack(side="left", padx=2)
        ttk.Button(mrow, text="Stop", command=lambda: (stop_music(), stop_guitar())).pack(side="left", padx=2)
        ttk.Button(mrow, text="Music folder", command=self.open_music).pack(side="left", padx=2)
        self.music_info = tk.StringVar(value="")
        ttk.Label(t, textvariable=self.music_info, wraplength=360, foreground="#cbbac7").pack(anchor="w")

        # --- PC control ---
        t = tabs["PC control"]
        self.check(t, "Let Uzi control this PC (browser tabs, YouTube, Spotify)", "PC_CONTROL", sync=True)
        self.check(t, "...also when I ask from my phone", "PHONE_CONTROL", sync=True)
        self.check(t, "Advanced: apps, volume, windows, typing, screenshots, shut down", "PC_FULL", sync=True)
        ttk.Label(t, wraplength=420, foreground="#cbbac7", text=(
            "Advanced commands: 'open Discord', 'open downloads', 'volume up', 'mute', 'scroll down', 'type hello', "
            "'copy', 'paste', 'minimize this', 'show desktop', 'lock the PC', 'take a screenshot', 'close this window', "
            "'shut down the PC'. Closing a window, sleep, shutdown and restart ask for a 'yes' first, and shutdown "
            "waits 30 seconds ('cancel shutdown' stops it). She never deletes files, runs commands, opens a "
            "terminal, presses Enter, types passwords or buys things. Everything she does is written to "
            "uzi_actions.log.")).pack(anchor="w", pady=4)
        ctrl = ttk.Frame(t)
        ctrl.pack(fill="x", pady=2)
        ttk.Button(ctrl, text="Turn ALL PC control off", command=self.panic).pack(side="left", padx=2)
        ttk.Button(ctrl, text="Open action log", command=self.open_log).pack(side="left", padx=2)
        ttk.Label(t, wraplength=420, foreground="#cbbac7", text=(
            "Try saying: 'close this tab', 'open a new tab', 'go to YouTube', 'search lofi beats on YouTube', "
            "'add Numb to my playlist', 'queue Radioactive', 'play Believer on Spotify', 'pause Spotify'. "
            "Tab commands only work on a browser window (Chrome, Edge, Firefox, Brave, Opera, Vivaldi). "
            "The command has to come first in the sentence, so normal chatting won't trigger anything.")
                  ).pack(anchor="w", pady=4)
        sp = ttk.LabelFrame(t, text="Spotify (needs Premium)", padding=6)
        sp.pack(fill="x", pady=4)
        ttk.Label(sp, wraplength=400, foreground="#cbbac7", text=(
            "1) developer.spotify.com/dashboard > Create app.  2) Redirect URI: http://127.0.0.1:8888/callback  "
            "3) Paste the Client ID below and press Connect.")).pack(anchor="w")
        self.sp_id = tk.StringVar(value=SPOTIFY_CLIENT_ID)
        self.sp_pl = tk.StringVar(value=SPOTIFY_PLAYLIST)
        r1 = ttk.Frame(sp)
        r1.pack(fill="x", pady=2)
        ttk.Label(r1, text="Client ID", width=11).pack(side="left")
        ttk.Entry(r1, textvariable=self.sp_id, width=42).pack(side="left")
        r2 = ttk.Frame(sp)
        r2.pack(fill="x", pady=2)
        ttk.Label(r2, text="Playlist", width=11).pack(side="left")
        ttk.Entry(r2, textvariable=self.sp_pl, width=42).pack(side="left")
        r3 = ttk.Frame(sp)
        r3.pack(fill="x", pady=4)
        ttk.Button(r3, text="Connect", command=self.connect_spotify).pack(side="left", padx=2)
        ttk.Button(r3, text="Disconnect", command=self.disconnect_spotify).pack(side="left", padx=2)
        ttk.Button(r3, text="Open dashboard", command=lambda: webbrowser.open(
            "https://developer.spotify.com/dashboard")).pack(side="left", padx=2)
        self.sp_state = tk.StringVar(value="")
        ttk.Label(sp, textvariable=self.sp_state, foreground="#cbbac7").pack(anchor="w")

        # --- Camera ---
        t = tabs["Camera"]
        self.check(t, "Let Uzi see me through my webcam", "CAMERA_ENABLED")
        self.check(t, "Let her glance at me now and then", "CAM_GLANCE")
        self.slider(t, "Glance every ~(min)", 5, 60, CAM_EVERY, setg("CAM_EVERY"))
        crow = ttk.Frame(t)
        crow.pack(fill="x", pady=4)
        ttk.Label(crow, text="Camera number:").pack(side="left")
        self.cam_var = tk.StringVar(value=str(CAM_INDEX))
        ttk.Spinbox(crow, from_=0, to=5, width=4, textvariable=self.cam_var,
                    command=self.on_cam_index).pack(side="left", padx=6)
        brow = ttk.Frame(t)
        brow.pack(fill="x", pady=4)
        ttk.Button(brow, text="Test camera", command=self.test_camera).pack(side="left", padx=2)
        ttk.Button(brow, text="Look at me now", command=self.look_now).pack(side="left", padx=2)
        ttk.Label(t, wraplength=360, foreground="#cbbac7", text=(
            "One-time setup: 'pip install opencv-python' and 'ollama pull moondream' (~1.7 GB). "
            "Pictures are described on your own PC and never saved or sent anywhere. "
            "Your webcam light turns on while she looks.")).pack(anchor="w", pady=4)

        # --- Phone ---
        t = tabs["Phone"]
        self.v_phone = tk.BooleanVar(value=PHONE_ENABLED)
        ttk.Checkbutton(t, text="Enable the phone page", variable=self.v_phone,
                        command=self.on_phone).pack(anchor="w")
        ttk.Button(t, text="Create Wi-Fi link", command=self.create_phone_link).pack(anchor="w", pady=(4, 2))
        self.check(t, "Allow phone link to view the PC screen (sensitive)", "PHONE_SCREEN_VIEW")
        self.phone_info = tk.StringVar(value="")
        ttk.Label(t, textvariable=self.phone_info, wraplength=420, foreground="#cbbac7").pack(anchor="w", pady=4)
        ttk.Label(t, text="Phone link").pack(anchor="w")
        self.phone_entry = ttk.Entry(t, width=56)
        self.phone_entry.pack(fill="x")
        prow = ttk.Frame(t)
        prow.pack(fill="x", pady=4)
        ttk.Button(prow, text="Open link", command=self.open_phone_link).pack(side="left", padx=2)
        ttk.Button(prow, text="Copy link", command=self.copy_link).pack(side="left", padx=2)
        ttk.Button(prow, text="Refresh", command=self.refresh_phone).pack(side="left", padx=2)
        ttk.Label(t, wraplength=420, foreground="#cbbac7", text=(
            "Same local network only: connect your phone and PC to the same Wi-Fi or LAN, then open or scan this link. "
            "Chat and optional screen preview work here; phone microphone and calls require HTTPS.")).pack(anchor="w")
        self.qr_label = ttk.Label(t)
        self.qr_label.pack(pady=4)
        self.qr_img = None

        # --- Memory ---
        t = tabs["Memory"]
        self.check(t, "Remember our chats", "MEMORY_ON")
        self.mem_info = tk.StringVar(value="")
        ttk.Label(t, textvariable=self.mem_info, foreground="#cbbac7").pack(anchor="w", pady=4)
        ttk.Button(t, text="What does she remember?", command=self.show_memory).pack(anchor="w", pady=2)
        ttk.Button(t, text="Forget everything", command=self.forget).pack(anchor="w", pady=2)

        self.status_var = tk.StringVar(value="Ready.")
        ttk.Label(main, textvariable=self.status_var, wraplength=400, style="Uzi.Status.TLabel").pack(anchor="w", pady=4)
        ttk.Button(main, text="Quit Uzi", command=app.quit).pack(anchor="e")
        self.refresh_phone()

    # --- hjälpare ---
    def check(self, parent, text, gname, after=None, sync=False):
        var = tk.BooleanVar(value=globals()[gname])

        def cmd():
            globals()[gname] = var.get()
            save_settings()
            if after:
                after()
        ttk.Checkbutton(parent, text=text, variable=var, command=cmd).pack(anchor="w")
        if sync:
            self.synced.append((gname, var))
        return var

    def slider(self, parent, text, lo, hi, val, cmd):
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text=text, width=18).pack(side="left")
        lbl = ttk.Label(row, text=str(int(val)), width=5)
        lbl.pack(side="right")
        sc = ttk.Scale(row, from_=lo, to=hi, value=val, orient="horizontal",
                       command=lambda v, c=cmd, l=lbl: (l.config(text=str(int(float(v)))), c(int(float(v)))))
        sc.pack(side="left", fill="x", expand=True)
        sc.bind("<ButtonRelease-1>", lambda e: save_settings())
        return lbl

    def status(self, text):
        self.status_var.set(text)

    def load_character_preset(self, _event=None):
        preset = self.character_preset_var.get()
        self.personality_text.delete("1.0", "end")
        self.personality_text.insert("1.0", PERSONALITY_PRESETS.get(preset, ""))

    def browse_character_image(self):
        path = filedialog.askopenfilename(parent=self.win, title="Choose character image",
                                          filetypes=(("Image files", "*.png *.jpg *.jpeg *.jfif *.webp *.bmp"),
                                                     ("All files", "*.*")))
        if path:
            self.character_image_var.set(path)

    def browse_couch_image(self):
        path = filedialog.askopenfilename(parent=self.win, title="Choose couch image",
                                          filetypes=(("Image files", "*.png *.jpg *.jpeg *.jfif *.webp *.bmp"),
                                                     ("All files", "*.*")))
        if path:
            self.couch_image_var.set(path)

    def refresh_artwork(self):
        global sprite_png_cache
        sprite_png_cache = None
        self.app.sprite_src = load_sprite()
        self.app.build_images(SPRITE_HEIGHT)
        monitor = self.app.my_monitor()
        self.app.x = max(monitor[0], min(self.app.x, monitor[2] - self.app.w))
        self.app.couch.refresh()
        self.app.cur_key = None
        self.app.set_image()

    def apply_character(self):
        global CHARACTER_PRESET, CHARACTER_IMAGE, PERSONALITY_TEXT
        preset = self.character_preset_var.get()
        image = self.character_image_var.get().strip()
        if image and not os.path.isfile(image):
            self.status("Character image file not found.")
            return
        if image:
            try:
                with Image.open(image) as portrait:
                    portrait.verify()
            except Exception as e:
                self.status(f"Could not load character image: {e}")
                return
        personality = self.personality_text.get("1.0", "end-1c").strip()
        if preset == "Custom" and not personality:
            self.status("Add a personality description for the custom character first.")
            return
        CHARACTER_PRESET = preset
        CHARACTER_IMAGE = image
        PERSONALITY_TEXT = personality
        history.clear()
        save_settings()
        self.refresh_artwork()
        self.status(f"Character applied: {CHARACTER_PRESET}.")

    def apply_couch(self):
        global COUCH_STYLE, COUCH_IMAGE
        image = self.couch_image_var.get().strip()
        if image and not os.path.isfile(image):
            self.status("Couch image file not found.")
            return
        if image:
            try:
                with Image.open(image) as couch_image:
                    couch_image.verify()
            except Exception as e:
                self.status(f"Could not load couch image: {e}")
                return
        COUCH_STYLE = self.couch_style_var.get()
        COUCH_IMAGE = image
        save_settings()
        self.refresh_artwork()
        self.status("Couch appearance applied.")

    def sync(self):
        for gname, var in self.synced:
            var.set(globals()[gname])
        self.sp_state.set("Spotify: connected." if spotify_connected() else "Spotify: not connected.")
        n = len(music_files())
        now = f"  Now playing: {music_title}" if music_playing() else ("  \u266b Guitar!" if guitar_playing() else "")
        self.music_info.set(f"{n} song(s) in the music folder.{now}" if n else
                            "No songs yet. Click 'Music folder' and drop some mp3 files in it. (The guitar needs none.)")
        self.mem_info.set(f"{len(memory['log'])} chats remembered."
                          + (" Notes written." if memory.get("summary") else ""))

    # --- knappar ---
    def open_music(self):
        try:
            os.startfile(MUSIC_DIR)
        except Exception as e:
            self.status(f"Could not open the folder: {e}")

    def on_cam_index(self):
        global CAM_INDEX
        try:
            CAM_INDEX = int(self.cam_var.get())
            save_settings()
        except ValueError:
            pass

    def test_camera(self):
        self.status("Opening the camera...")

        def run():
            try:
                capture_frame_b64()
                msg = "Camera works. (Try another camera number if it's the wrong one.)"
            except ImportError:
                msg = "OpenCV is missing. Run in cmd: pip install opencv-python"
            except Exception as e:
                msg = f"Camera problem: {e}"
            ui_q.put(lambda: self.status(msg))
        threading.Thread(target=run, daemon=True).start()

    def look_now(self):
        if not CAMERA_ENABLED:
            self.status("Tick 'Let Uzi see me through my webcam' first.")
            return
        threading.Thread(target=look_at_user, args=("Comment in character on what you see.",),
                         daemon=True).start()

    def panic(self):
        global PC_CONTROL, PC_FULL, PHONE_CONTROL
        PC_CONTROL = PC_FULL = PHONE_CONTROL = False
        pending_confirm.clear()
        save_settings()
        self.sync()
        self.status("All PC control is OFF.")

    def open_log(self):
        try:
            open(ACTION_LOG, "a", encoding="utf-8").close()
            os.startfile(ACTION_LOG)
        except Exception as e:
            self.status(f"Could not open the log: {e}")

    def save_spotify_fields(self):
        global SPOTIFY_CLIENT_ID, SPOTIFY_PLAYLIST
        SPOTIFY_CLIENT_ID = self.sp_id.get().strip()
        SPOTIFY_PLAYLIST = self.sp_pl.get().strip() or "Uzi picks"
        save_settings()

    def connect_spotify(self):
        self.save_spotify_fields()
        threading.Thread(target=spotify_connect,
                         args=(lambda m: ui_q.put(lambda m=m: self.status(m)),), daemon=True).start()

    def disconnect_spotify(self):
        spotify_disconnect()
        self.status("Spotify disconnected.")

    def on_phone(self):
        global PHONE_ENABLED
        PHONE_ENABLED = self.v_phone.get()
        if PHONE_ENABLED:
            start_phone()
        else:
            stop_phone()
        save_settings()
        self.status("Local phone page ready." if phone_server is not None else phone_error or "Phone page is off.")
        self.refresh_phone()

    def create_phone_link(self):
        global PHONE_ENABLED
        PHONE_ENABLED = True
        self.v_phone.set(True)
        save_settings()
        if start_phone():
            self.status("Local Wi-Fi link ready. Connect your phone to the same Wi-Fi.")
        else:
            self.status(phone_error or "Could not start the local phone page.")
        self.refresh_phone()

    def refresh_phone(self):
        self._show_phone()

    def _show_phone(self):
        self.phone_entry.delete(0, "end")
        self.qr_label.config(image="")
        self.qr_img = None
        if phone_server is None:
            self.phone_info.set(phone_error or "Off. Tick 'Enable the phone page'.")
            return
        url = phone_url()
        self.phone_info.set("Same local network only. Connect your phone to the same Wi-Fi or LAN to open the link.")
        self.phone_entry.insert(0, url)
        try:
            import qrcode
            img = qrcode.make(url)
            img = getattr(img, "get_image", lambda: img)().convert("RGB").resize((170, 170))
            self.qr_img = ImageTk.PhotoImage(img)
            self.qr_label.config(image=self.qr_img)
        except ImportError:
            self.phone_info.set("Local page is running, but QR support is missing. Start Uzi with Run.bat to install it.")
        except Exception as e:
            self.phone_info.set(f"Local page is running, but QR creation failed: {e}")

    def copy_link(self):
        url = self.phone_entry.get()
        if url:
            self.win.clipboard_clear()
            self.win.clipboard_append(url)
            self.status("Link copied.")

    def open_phone_link(self):
        url = self.phone_entry.get().strip()
        if not url:
            self.status(phone_error or "Create the local phone link first.")
            return
        webbrowser.open(url)
        self.status("Opened the local phone page on this PC.")

    def show_memory(self):
        w = tk.Toplevel(self.win)
        w.title("What Uzi remembers")
        w.geometry("540x440+140+140")
        txt = tk.Text(w, wrap="word", padx=8, pady=8)
        sb = ttk.Scrollbar(w, command=txt.yview)
        txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        txt.pack(fill="both", expand=True)
        with memory_lock:
            lines = ["NOTES (what she thinks she knows about you):",
                     memory.get("summary") or "(nothing yet)", "", "RECENT CHATS:"]
            for e in memory["log"][-40:]:
                lines += [f"[{e.get('t', '')}] You: {e['user']}", f"      Uzi: {e['uzi']}", ""]
        txt.insert("1.0", "\n".join(lines))
        txt.config(state="disabled")

    def forget(self):
        if messagebox.askyesno("Forget everything", "Delete everything Uzi remembers about you?",
                               parent=self.win):
            with memory_lock:
                memory.update({"summary": "", "log": [], "since": 0})
                save_memory()
            history.clear()
            self.status("Memory wiped. She remembers nothing. Lucky her.")

    def on_mic_pick(self, _e=None):
        global MIC_DEVICE
        MIC_DEVICE = self.devs[self.combo.current()][0]
        save_settings()
        self.status(f"Microphone: {self.combo.get()}")

    def test_brain(self):
        self.status("Checking Ollama...")
        threading.Thread(target=lambda: (lambda m: ui_q.put(lambda: self.status(m)))(brain_status()),
                         daemon=True).start()

    def test_voice(self):
        self.app.say("Hello. This is Uzi. Can you hear me?")

    def test_mic(self):
        self.status("Speak now... (3 seconds)")

        def run():
            try:
                import sounddevice as sd
                peak = 0.0
                with sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype="float32",
                                    blocksize=1600, device=MIC_DEVICE) as st:
                    t0 = time.time()
                    while time.time() - t0 < 3:
                        d, _ = st.read(1600)
                        peak = max(peak, float(np.sqrt(np.mean(d ** 2))))
                if peak < 0.005:
                    msg = f"Almost no signal (peak {peak:.4f}). Wrong mic, muted, or blocked in Windows privacy settings."
                elif peak < 0.02:
                    msg = f"Weak signal (peak {peak:.4f}). It works, but raise the mic volume in Windows."
                else:
                    msg = f"Good signal (peak {peak:.4f}). This microphone works."
            except Exception as e:
                msg = f"Mic error: {e}"
            ui_q.put(lambda: self.status(msg))
        threading.Thread(target=run, daemon=True).start()


# ---------------- Uzi själv ----------------
class Uzi:
    REACTIONS = {
        "pickup": ["Hey! Hands off!", "Put me down. Now.", "Ugh, what are you doing?!",
                   "Do I look like a stress toy?"],
        "drop": ["AAAH! I did not agree to this, you absolute jerk!", "Shit! Put me down--carefully!",
             "Whoa, whoa, WHOA! I'm not ready to die!"],
        "land": ["Ow! Shit! Warn me before you drop me!", "That was terrifying. My knees are filing a complaint.",
             "Okay, okay, I'm alive. Don't do that again!"],
        "hover": ["...can I help you?", "Your cursor is on me. Creepy.", "Stop hovering. It's weird.",
                  "Yes? No? Okay, then stop.", "Don't poke the emo."],
        "poke": ["Ow.", "Hey!", "What.", "Rude."],
        "cross": ["Changing scenery. Not that it helps.", "Other screen. Same misery."],
        "sit": ["Couch. Finally.", "Don't talk to me. I'm busy sitting.", "This couch is the only one who gets me."],
    }
    COOLDOWN = {"hover": 12, "poke": 4, "cross": 60, "sit": 300}

    def __init__(self):
        self.root = tk.Tk()
        r = self.root
        r.overrideredirect(True)
        r.attributes("-topmost", True)
        r.attributes("-transparentcolor", KEY)
        r.config(bg=KEY)

        self.mons = get_monitors() or [(0, 0, r.winfo_screenwidth(), r.winfo_screenheight() - 48)]
        self.sprite_src = load_sprite()
        self.dir = 1
        self.cur_key = None
        self.build_images(SPRITE_HEIGHT)
        self.label = tk.Label(r, image=self.imgs["R"], bg=KEY, bd=0)
        self.label.pack()
        self.cur_key = "R"

        m = random.choice(self.mons)
        self.x = random.randint(m[0], max(m[0], m[2] - self.w))
        self.y = m[3] - self.h
        self.walking = saved.get("walk", True)
        self.visible = True
        self.dragging = False
        self.airborne = False
        self.hovered = False
        self.hover_job = None
        self.resize_job = None
        self.vy = 0
        self.drop_y = self.y
        self.off_x = self.off_y = 0
        self.press_xy = (0, 0)
        self.last_react = {}
        self.pause_ticks = 0
        self.mon_tick = 0
        self.sitting = False
        self.sit_goal = False
        self.sit_until = 0.0
        self.active_rect = None
        self.window_surfaces = visible_window_rects()
        self.platform_kind = None
        self.platform_hwnd = None
        self.platform_rect = None
        self.climb_rect = None
        self.climb_hwnd = None
        self.climb_monitor = None
        self.climb_stage = None
        self.climb_side = -1
        self.climb_floor = self.ground_y()
        self.climb_cooldown = 0.0
        self.window_poll = 0

        self.menu = tk.Menu(r, tearoff=0)
        self.menu.add_command(label="Talk (mic)", command=self.mic)
        self.menu.add_command(label="Type to Uzi", command=self.type_to)
        self.menu.add_command(label="Control panel", command=self.panel_show)
        self.menu.add_command(label="Climb active window", command=self.climb_active_window)
        self.menu.add_command(label="Stop music / guitar", command=lambda: (stop_music(), stop_guitar()))
        self.menu.add_command(label="Make her sit on the couch", command=request_sit)
        self.menu.add_command(label="TURN OFF PC control", command=self.panic_off)
        self.menu.add_separator()
        self.menu.add_command(label="Quit", command=self.quit)
        self.label.bind("<Button-3>", lambda e: self.menu.tk_popup(e.x_root, e.y_root))
        self.label.bind("<ButtonPress-1>", self.on_press)
        self.label.bind("<B1-Motion>", self.on_drag)
        self.label.bind("<ButtonRelease-1>", self.on_release)
        self.label.bind("<Enter>", self.on_enter)
        self.label.bind("<Leave>", self.on_leave)

        self.bubble = tk.Toplevel(r)
        self.bubble.overrideredirect(True)
        self.bubble.attributes("-topmost", True)
        self.btext = tk.Label(self.bubble, text="", bg="#2b1b3d", fg="#f2e6ff", wraplength=260,
                              justify="left", padx=10, pady=8, font=("Segoe UI", 10),
                              relief="solid", bd=1)
        self.btext.pack()
        self.bubble.withdraw()
        self.hide_job = None

        self.button = TalkButton(self)
        self.couch = Couch(self)
        self.panel = Panel(self)

        self.say("...what. I'm here. Click the purple button to talk to me.")
        self.tick()
        self.poll()

    # ----- sprite -----
    def build_images(self, height):
        global SPRITE_HEIGHT
        SPRITE_HEIGHT = height
        sp = self.sprite_src
        w = max(10, int(sp.width * height / sp.height))
        sp = sp.resize((w, height), Image.LANCZOS)

        def keyed(im):
            bg = Image.new("RGB", im.size, KEY)
            bg.paste(im, mask=im.split()[3].point(lambda p: 255 if p > 128 else 0))
            return ImageTk.PhotoImage(bg)

        self.imgs = {"R": keyed(sp), "L": keyed(sp.transpose(Image.FLIP_LEFT_RIGHT))}
        glayers = {}
        for f in (0, 1):                                       # med gitarr, två "stråk"-bilder
            comp = glayers[f] = Image.alpha_composite(sp, guitar_layer(w, height, f))
            self.imgs[f"GR{f}"] = keyed(comp)
            self.imgs[f"GL{f}"] = keyed(comp.transpose(Image.FLIP_LEFT_RIGHT))
        cw, ch = int(w * 2.4), int(height)                     # soffa: ensam, och med henne sittande (± gitarr)
        try:
            if COUCH_IMAGE:
                with Image.open(COUCH_IMAGE) as custom_couch:
                    couch = ImageOps.fit(custom_couch.convert("RGBA"), (cw, ch), method=Image.LANCZOS)
            else:
                couch = draw_couch(cw, ch, height)
        except Exception:
            couch = draw_couch(cw, ch, height)

        def seated(layer):
            canvas = couch.copy()
            canvas.alpha_composite(layer, ((cw - w) // 2, ch - height))
            return canvas
        self.imgs["C"] = keyed(couch)
        sit = seated(sp)
        self.imgs["SR"], self.imgs["SL"] = keyed(sit), keyed(sit.transpose(Image.FLIP_LEFT_RIGHT))
        for f in (0, 1):
            sg = seated(glayers[f])
            self.imgs[f"SGR{f}"], self.imgs[f"SGL{f}"] = keyed(sg), keyed(sg.transpose(Image.FLIP_LEFT_RIGHT))
        self.cw, self.ch = cw, ch
        self.w, self.h = w, height

    def set_image(self):
        d = "R" if self.dir > 0 else "L"
        if self.sitting:
            key = ("SG" + d + str(int(time.time() * 4) % 2)) if guitar_playing() else "S" + d
        elif guitar_playing():
            key = "G" + d + str(int(time.time() * 4) % 2)
        else:
            key = d
        if key != self.cur_key:
            self.cur_key = key
            self.label.config(image=self.imgs[key])

    def schedule_resize(self, v):
        if self.resize_job:
            self.root.after_cancel(self.resize_job)
        self.resize_job = self.root.after(250, lambda: self.resize(v))

    def resize(self, v):
        self.build_images(v)
        self.cur_key = None
        self.couch.refresh()
        self.set_image()
        self.y = self.ground_y()
        save_settings()

    # ----- skärmar -----
    def monitor_at(self, cx, cy):
        best, bd = self.mons[0], None
        for m in self.mons:
            dx = max(m[0] - cx, 0, cx - m[2])
            dy = max(m[1] - cy, 0, cy - m[3])
            d = dx * dx + dy * dy
            if bd is None or d < bd:
                best, bd = m, d
        return best

    def my_monitor(self):
        return self.monitor_at(self.x + self.w // 2, self.y + self.h - 2)

    def ground_y(self):
        return self.my_monitor()[3] - self.h

    def window_platform_nearby(self, foot_y, tolerance=24):
        candidates = []
        for hwnd, rect in self.window_surfaces:
            left, top, right, _ = rect
            if self.x + self.w <= left + 4 or self.x >= right - 4:
                continue
            delta = abs(foot_y - top)
            if delta <= tolerance:
                candidates.append((delta, "window", hwnd, rect))
        if COUCH_ENABLED and not self.sitting:
            left, top, right = self.couch.x, self.couch.platform_y(), self.couch.x + self.cw
            if self.x + self.w > left + 4 and self.x < right - 4:
                delta = abs(foot_y - top)
                if delta <= tolerance:
                    candidates.append((delta, "couch", None, (left, top, right, self.couch.y + self.ch)))
        if not candidates:
            return None
        _, kind, hwnd, rect = min(candidates)
        return kind, hwnd, rect

    def window_landed_on(self, old_foot, new_foot):
        candidates = []
        for hwnd, rect in self.window_surfaces:
            left, top, right, _ = rect
            if (old_foot <= top <= new_foot and self.x + self.w > left + 4
                    and self.x < right - 4):
                candidates.append((top, 0, hwnd, rect))
        if COUCH_ENABLED and not self.sitting:
            left, top, right = self.couch.x, self.couch.platform_y(), self.couch.x + self.cw
            if old_foot <= top <= new_foot and self.x + self.w > left + 4 and self.x < right - 4:
                candidates.append((top, 1, None,
                                   (left, top, right, self.couch.y + self.ch)))
        if not candidates:
            return None
        _, priority, hwnd, rect = min(candidates)
        return ("couch" if priority else "window"), hwnd, rect

    def current_platform(self):
        if self.platform_kind == "couch":
            if (COUCH_ENABLED and not self.sitting and self.x + self.w > self.couch.x + 4
                    and self.x < self.couch.x + self.cw - 4):
                top = self.couch.platform_y()
                self.platform_rect = (self.couch.x, top, self.couch.x + self.cw, self.couch.y + self.ch)
                return self.platform_rect
            self.platform_kind = None
            self.platform_rect = None
            return None
        if self.platform_kind != "window":
            return None
        if self.platform_hwnd is None:
            return None
        for hwnd, rect in self.window_surfaces:
            if hwnd == self.platform_hwnd:
                left, _, right, _ = rect
                if self.x + self.w > left + 4 and self.x < right - 4:
                    self.platform_rect = rect
                    return rect
                self.platform_kind = None
        self.platform_hwnd = None
        self.platform_rect = None
        return None

    # ----- knappar -----
    # ----- soffa -----
    def couch_toggle(self):
        if not COUCH_ENABLED:
            self.sit_goal = False
            if self.sitting:
                self.stand_up()
        self.couch.apply()

    def sit_down(self):
        self.sitting, self.sit_goal = True, False
        self.sit_until = time.time() + random.uniform(40, 180)
        self.cur_key = None
        self.couch.apply()
        self.react("sit")

    def stand_up(self, drag=False):
        was, self.sitting = self.sitting, False
        self.cur_key = None
        self.couch.apply()
        if drag:
            self.off_x, self.off_y = self.w // 2, self.h // 2
        elif was:
            self.x = self.couch.x + (self.cw - self.w) // 2
            self.y = self.couch.platform_y() - self.h
            self.platform_kind = "couch"
            self.platform_hwnd = None
            self.platform_rect = (self.couch.x, self.couch.platform_y(),
                                  self.couch.x + self.cw, self.couch.y + self.ch)
            self.airborne = False
            self.vy = 0

    def walk_to_couch(self):
        target = self.couch.x + (self.cw - self.w) // 2
        cm = self.monitor_at(self.couch.x + self.cw // 2, self.couch.y + self.ch - 2)
        if cm != self.my_monitor():                            # soffan står på en annan skärm: hoppa dit
            self.x = max(cm[0], min(target + random.choice((-1, 1)) * (self.cw // 2 + 40), cm[2] - self.w))
            self.y = cm[3] - self.h
            return
        if abs(target - self.x) <= 4:
            self.x = target
            self.sit_down()
        else:
            self.dir = 1 if target > self.x else -1
            self.x += 3 * self.dir

    def begin_climb(self, rect=None, manual=False):
        rect = rect or self.active_rect
        if not rect:
            if manual:
                self.panel.status("No active app window to climb. Click the window, then try again.")
            return False
        monitor = self.my_monitor()
        left, top, right, bottom = rect
        left, right = max(left, monitor[0]), min(right, monitor[2])
        top = max(top, monitor[1])
        if right - left < self.w * 2 or bottom <= top:
            if manual:
                self.panel.status("That window is too small or on another screen to climb.")
            return False
        self.climb_rect = (left, top, right, bottom)
        self.climb_hwnd = next((hwnd for hwnd, bounds in self.window_surfaces if bounds == rect), None)
        self.climb_monitor = monitor
        left_x = max(monitor[0], min(left - self.w // 2, monitor[2] - self.w))
        right_x = max(monitor[0], min(right - self.w // 2, monitor[2] - self.w))
        self.climb_side = -1 if abs(self.x - left_x) <= abs(self.x - right_x) else 1
        self.climb_floor = monitor[3] - self.h
        self.climb_stage = "approach"
        self.airborne = False
        self.vy = 0
        self.sit_goal = False
        if self.sitting:
            self.stand_up()
        self.climb_cooldown = time.time() + 90
        return True

    def climb_active_window(self):
        self.begin_climb(manual=True)

    def move_climb(self):
        left, top, right, _ = self.climb_rect
        monitor = self.climb_monitor
        left_x = max(monitor[0], min(left - self.w // 2, monitor[2] - self.w))
        right_x = max(monitor[0], min(right - self.w // 2, monitor[2] - self.w))
        top_y = max(monitor[1], top - self.h)
        side_x = left_x if self.climb_side < 0 else right_x
        other_x = right_x if self.climb_side < 0 else left_x
        if self.climb_stage == "approach":
            self.dir = 1 if side_x > self.x else -1
            self.x += self.dir * min(3, abs(side_x - self.x))
            if self.x == side_x:
                self.climb_stage = "up"
        elif self.climb_stage == "up":
            self.y = max(top_y, self.y - 3)
            if self.y == top_y:
                self.climb_stage = "across"
                self.platform_kind = "window"
                self.platform_hwnd = self.climb_hwnd
                self.platform_rect = self.climb_rect if self.climb_hwnd else None
                self.dir = 1 if other_x > self.x else -1
        elif self.climb_stage == "across":
            self.x += self.dir * min(2, abs(other_x - self.x))
            if self.x == other_x:
                self.climb_stage = "down"
                self.platform_kind = None
                self.platform_hwnd = None
                self.platform_rect = None
        elif self.climb_stage == "down":
            self.y = min(self.climb_floor, self.y + 3)
            if self.y == self.climb_floor:
                self.climb_stage = None
                self.climb_rect = None
                self.climb_hwnd = None
                self.climb_monitor = None
                self.pause_ticks = 40

    def panic_off(self):
        global PC_CONTROL, PC_FULL, PHONE_CONTROL
        PC_CONTROL = PC_FULL = PHONE_CONTROL = False
        pending_confirm.clear()
        save_settings()
        self.say("PC control is OFF. Back in my box.", speak=False)

    # ----- knappar -----
    def mic(self):
        stop_speaking()
        stop_music()
        stop_guitar()
        threading.Thread(target=mic_once, daemon=True).start()

    def type_to(self):
        t = simpledialog.askstring("Uzi", "Say something to Uzi:", parent=self.root)
        if t:
            self.say("...", speak=False)
            answer_async(t)

    def panel_show(self):
        self.panel.win.deiconify()
        self.panel.win.lift()

    def set_visible(self, v):
        self.visible = v
        if not v:
            self.bubble.withdraw()

    def quit(self):
        saved["last_seen"] = time.time()
        save_settings()
        stop_music()
        stop_guitar()
        stop_speaking()
        stop_phone()
        self.root.destroy()

    # ----- reaktioner -----
    def react(self, kind):
        cd = self.COOLDOWN.get(kind, 3)
        now = time.time()
        if now - self.last_react.get(kind, 0) < cd or now - self.last_react.get("any", 0) < 2:
            return
        self.last_react[kind] = self.last_react["any"] = now
        self.say(random.choice(self.REACTIONS[kind]))

    def on_press(self, e):
        self.off_x, self.off_y = e.x, e.y
        self.press_xy = (e.x_root, e.y_root)

    def on_drag(self, e):
        if not self.dragging:
            if abs(e.x_root - self.press_xy[0]) + abs(e.y_root - self.press_xy[1]) < 8:
                return
            self.dragging = True
            self.airborne = False
            self.platform_kind = None
            self.platform_hwnd = None
            self.platform_rect = None
            self.vy = 0
            if self.sitting:
                self.stand_up(drag=True)
            self.react("pickup")
        lo_x, hi_x = min(m[0] for m in self.mons), max(m[2] for m in self.mons)
        lo_y, hi_y = min(m[1] for m in self.mons), max(m[3] for m in self.mons)
        self.x = max(lo_x, min(e.x_root - self.off_x, hi_x - self.w))
        self.y = max(lo_y, min(e.y_root - self.off_y, hi_y - self.h))

    def on_release(self, e):
        if not self.dragging:
            self.react("poke")
            return
        self.dragging = False
        landed = self.window_platform_nearby(self.y + self.h)
        if landed:
            self.platform_kind, self.platform_hwnd, self.platform_rect = landed
            self.y = self.platform_rect[1] - self.h
            self.airborne = False
            self.vy = 0
        elif self.y < self.ground_y() - 5:
            self.airborne = True
            self.vy = 0
            self.drop_y = self.y
            if self.ground_y() - self.y > 80:
                self.react("drop")

    def on_enter(self, e):
        if self.dragging:
            return
        self.hovered = True
        if self.hover_job:
            self.root.after_cancel(self.hover_job)
        self.hover_job = self.root.after(450, self.hover_react)

    def on_leave(self, e):
        self.hovered = False
        if self.hover_job:
            self.root.after_cancel(self.hover_job)
            self.hover_job = None

    def hover_react(self):
        self.hover_job = None
        if self.hovered and not self.dragging:
            self.react("hover")

    # ----- pratbubbla -----
    def say(self, text, speak=True):
        self.btext.config(text=text)
        if self.visible:
            self.bubble.deiconify()
            self.place_bubble()
        if self.hide_job:
            self.root.after_cancel(self.hide_job)
        self.hide_job = self.root.after(6000 + 60 * len(text), self.bubble.withdraw)
        if speak and SPEAK:
            speaking.set()
            speech_q.put(text)

    def place_bubble(self):
        self.bubble.update_idletasks()
        bw, bh = self.bubble.winfo_width(), self.bubble.winfo_height()
        ax, ay, aw = ((self.couch.x, self.couch.y, self.cw) if self.sitting else (self.x, self.y, self.w))
        m = self.monitor_at(ax + aw // 2, ay + self.h - 2)
        bx = min(max(m[0], ax + aw // 2 - bw // 2), m[2] - bw)
        by = max(m[1], ay - bh - 4)
        self.bubble.geometry(f"+{int(bx)}+{int(by)}")

    # ----- huvudloop -----
    def tick(self):
        if not self.visible:
            self.root.geometry("1x1+-32000+-32000")
            self.root.after(200, self.tick)
            return
        global sit_request
        if sit_request:
            req, sit_request = sit_request, None
            if req == "sit" and COUCH_ENABLED:
                self.sit_goal = True
            elif req == "stand":
                self.sit_goal = False
                if self.sitting:
                    self.stand_up()
        if self.sitting and not self.dragging:
            if time.time() > self.sit_until and idle_seconds() < 120:   # är du borta sitter hon kvar
                self.stand_up()
            else:
                self.set_image()
                self.root.geometry(f"{self.cw}x{self.ch}+{int(self.couch.x)}+{int(self.couch.y)}")
                if self.bubble.winfo_viewable():
                    self.place_bubble()
                self.root.after(40, self.tick)
                return
        self.window_poll += 1
        if self.window_poll >= 15:
            self.window_poll = 0
            self.window_surfaces = visible_window_rects()
            rect = active_window_rect()
            if rect:
                self.active_rect = rect
        self.couch.physics_tick()
        if (self.climb_stage and self.climb_hwnd is not None
                and not any(hwnd == self.climb_hwnd for hwnd, _ in self.window_surfaces)):
            self.climb_stage = None
            self.climb_rect = None
            self.climb_hwnd = None
            self.climb_monitor = None
            self.platform_kind = None
            self.platform_hwnd = None
            self.platform_rect = None
            self.airborne = True
            self.drop_y = self.y
            self.vy = 0
        if (not self.dragging and not self.airborne and not self.climb_stage and CLIMB_WINDOWS
                and self.active_rect and time.time() >= self.climb_cooldown and random.random() < 0.0025):
            self.begin_climb()
        if self.dragging:
            pass
        elif self.climb_stage:
            self.move_climb()
        elif self.airborne:
            old_foot = self.y + self.h
            self.vy += 2
            self.y += self.vy
            g = self.ground_y()
            landed = self.window_landed_on(old_foot, self.y + self.h)
            if landed:
                self.platform_kind, self.platform_hwnd, self.platform_rect = landed
                self.y = self.platform_rect[1] - self.h
                self.airborne = False
                self.vy = 0
                self.pause_ticks = 40
                if self.y - self.drop_y > 120:
                    self.react("land")
            elif self.y >= g:
                self.y = g
                self.airborne = False
                self.platform_kind = None
                self.platform_hwnd = None
                self.platform_rect = None
                self.vy = 0
                self.pause_ticks = 40
                if g - self.drop_y > 120:
                    self.react("land")
        else:
            g = self.ground_y()
            had_platform = self.platform_kind is not None
            platform = self.current_platform()
            if platform:
                self.y = platform[1] - self.h
            elif had_platform and self.y < g - 1:
                self.airborne = True
                self.drop_y = self.y
                self.vy = 0
            elif self.y < g - 1:           # t.ex. gick ut över en kant till en lägre skärm
                self.airborne = True
                self.drop_y = self.y
                self.vy = 0
            elif self.y > g:
                self.y = g
                self.platform_kind = None
                self.platform_hwnd = None
                self.platform_rect = None
            if self.sit_goal and self.couch.enabled and not self.hovered:
                self.walk_to_couch()
            elif self.hovered or not self.walking or guitar_playing():
                pass
            elif self.pause_ticks > 0:
                self.pause_ticks -= 1
            else:
                old_mon = self.my_monitor()
                lo_x, hi_x = min(m[0] for m in self.mons), max(m[2] for m in self.mons)
                self.x += 2 * self.dir
                if self.x <= lo_x or self.x + self.w >= hi_x:
                    self.dir *= -1
                    self.x = max(lo_x, min(self.x, hi_x - self.w))
                if random.random() < 0.004:
                    self.pause_ticks = random.randint(40, 200)
                if random.random() < 0.003:
                    self.dir *= -1
                if self.couch.enabled and random.random() < (0.003 if idle_seconds() > 300 else 0.0004):
                    self.sit_goal = True                           # hon går och sätter sig i soffan ibland
                if len(self.mons) > 1 and random.random() < 0.0004:   # ibland går hon till en annan skärm
                    other = random.choice([m for m in self.mons if m != old_mon])
                    self.x = random.randint(other[0], max(other[0], other[2] - self.w))
                    self.y = other[3] - self.h
                    self.react("cross")
        self.set_image()
        self.root.geometry(f"{self.w}x{self.h}+{int(self.x)}+{int(self.y)}")
        if self.bubble.winfo_viewable():
            self.place_bubble()
        self.root.after(40, self.tick)

    def poll(self):
        try:
            while True:
                text, speak = events.get_nowait()
                if text:
                    self.say(text, speak=speak)
        except queue.Empty:
            pass
        try:
            while True:
                ui_q.get_nowait()()
        except queue.Empty:
            pass
        state = ui_state if ui_state != "idle" else ("speaking" if speaking.is_set() else "idle")
        self.button.set_state(state)
        self.panel.sync()
        self.mon_tick += 1
        if self.mon_tick % 40 == 0:             # kolla då och då om skärmar kopplats in/ur
            self.mons = get_monitors() or self.mons
            self.couch.snap()
        self.root.after(150, self.poll)

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    try:
        spotify_load()
        for fn in (speech_worker, comment_loop, listen_loop, music_loop, guitar_loop, miss_loop, cam_loop,
                   browser_tracker, brain_watch):
            threading.Thread(target=fn, daemon=True).start()
        try:
            import sounddevice as sd
            print("[mic] using:", sd.query_devices(MIC_DEVICE, "input")["name"])
        except Exception as e:
            print("[mic] could not open a microphone:", e)
        print("[music] folder:", MUSIC_DIR, "-", len(music_files()), "song(s)")
        print("[memory]", len(memory["log"]), "chats remembered")
        if PHONE_ENABLED:
            print("[phone]", phone_url() if start_phone() else phone_error)
        app = Uzi()
        print("[screens]", app.mons)
        app.run()
    except Exception:
        traceback.print_exc()
        input("\nSomething went wrong (see above). Press Enter to close...")

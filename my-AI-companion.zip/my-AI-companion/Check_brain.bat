@echo off
cd /d "%~dp0"
python brain_check.py
pause

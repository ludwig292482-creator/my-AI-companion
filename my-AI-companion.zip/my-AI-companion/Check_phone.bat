@echo off
cd /d "%~dp0"
python phone_check.py
pause

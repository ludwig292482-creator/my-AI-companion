# my-AI-companion (Uzi)

A **local, offline AI desktop companion** for Windows. Uzi is a character who lives on your
desktop: she talks to you, listens through your microphone, walks around your screens, sits
on a couch, plays guitar, remembers your chats, and has an angsty-emo-teenager personality.
The AI "brain" runs on your own PC through [Ollama](https://ollama.com), so nothing is sent
to a cloud service.

> Parts of this project were written with the help of AI tools.

## Features

- Talks out loud (English) and hears you through the mic with a press-to-talk button you can place anywhere on screen
- Walks across all your monitors and reacts to the mouse
- Sits on a couch you can drag wherever you want
- Plays music from your own music folder and plays (synthesized) guitar now and then
- Remembers past chats and "misses" you when you are away
- Control panel that explains every setting
- Optional (all **off by default**): webcam vision, a phone chat page, and PC control

## Requirements

- Windows 10 or 11
- About 8 GB RAM for the normal model, or 2-4 GB with the small model
- Internet for the first install (afterwards Uzi works offline)

## Install

1. Click **Code -> Download ZIP** on this page and unzip it somewhere (for example your Desktop).
2. Double-click **`Install.bat`**.
   - Windows may show a "protected your PC" warning because the file is not code-signed.
     You can open `Install.bat` in Notepad first. It is a short, readable script, and the
     list of what it does is at the top of the file.
   - If Windows asks for permission while installing Python or Ollama, that is the installer
     from those programs asking. You only need to allow those.
3. Answer the questions in the window:
   - **Model:** `1` for a normal PC (about 8 GB RAM), `2` for a weak PC (2-4 GB RAM)
   - **Webcam vision model:** optional (about 1.7 GB)
   - **Tailscale:** only if you want the phone page
4. If Python was missing, the installer installs it and asks you to run `Install.bat` once more.
5. When it says **ALL DONE**, double-click **`Run.bat`** to start Uzi.

### What Install.bat does

It only (1) checks for / installs Python 3.12 with `winget`, (2) installs Ollama with `winget`,
(3) optionally installs Tailscale with `winget`, (4) installs the packages in
`requirements.txt` with `pip`, and (5) downloads the chosen model with `ollama pull`.
It does not change system settings and does not download anything else.

### Manual install (if you prefer)

```
winget install Python.Python.3.12
winget install Ollama.Ollama
pip install -r requirements.txt
ollama pull gemma2:2b
ollama pull moondream        # optional, for the webcam
python uzi_offline.py
```

For a weak PC use `ollama pull qwen2.5:0.5b` and set `MODEL = "qwen2.5:0.5b"` near the top of `uzi_offline.py`.

## Using Uzi

1. Start with `Run.bat`. A character appears on the desktop, then a couch and a **control panel**.
2. The control panel explains what each setting does and how to use it.
3. Hold the press-to-talk button (drag it anywhere) and speak. Uzi answers out loud.
4. Drag the couch wherever you want her to sit.

### Your own character image

No character art is included in this repository. Uzi shows a simple purple placeholder until you
add your own picture: put a file named `uzi.png` (a PNG with a transparent background looks
best) in the same folder as `uzi_offline.py`, or pick an image in the control panel.
Only use art you made or have permission to use.

### Music

Put your own music files (mp3, wav, m4a, ...) in the music folder you choose in the control panel.

## Privacy and safety

- The AI runs locally through Ollama. Chat memory is stored only in a local file next to the program.
- **Webcam vision, the phone page, and PC control are all OFF by default.** You turn them on
  yourself in the control panel.
- Advanced PC control (apps, volume, windows, typing, shutdown) is off by default, asks before
  risky actions such as shutdown, and its actions are logged.
- The phone page is protected by a secret link and is meant to be used through Tailscale.
  Do not share your link.
- Nothing is uploaded anywhere by this program.

## Troubleshooting

| Problem | What to run |
| --- | --- |
| Uzi can't reach her brain | `Check_brain.bat` |
| Phone page does not open | `Check_phone.bat` (start Uzi first) |
| She can't hear you / no voice | `Test.bat` (microphone and voice test) |
| A package failed to install | Run `Install.bat` again, or `pip install -r requirements.txt` |

If an install fails on a very new Python version (some packages like `faster-whisper` can lag
behind), install Python 3.12 and try again.

## License

MIT - see [LICENSE](LICENSE). Replace the name in `LICENSE` with yours before publishing.
